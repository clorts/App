// Sons no navegador/app (pré-ouvir toques e tocar o alarme quando não há despertador nativo).
import { customUrl } from "./customSound.js";

const DEFAULT_TONE = { wave: "triangle", step: 280, notes: [523.25, 659.25, 783.99, 659.25, 880.0, 783.99, 659.25, 587.33] };

let ctx = null;
let master = null;
let timer = null;
let audioEl = null;
let rampTimer = null;

function stopCustom() {
  if (rampTimer !== null) clearInterval(rampTimer);
  rampTimer = null;
  if (audioEl) {
    audioEl.pause();
    audioEl = null;
  }
}

function playCustom(loop, soft) {
  stopCustom();
  const url = customUrl();
  if (!url) return false;
  const el = new Audio(url);
  el.loop = loop;
  el.volume = soft ? 0.25 : 1;
  el.play().catch(() => {});
  audioEl = el;
  if (soft) {
    const t0 = Date.now();
    rampTimer = setInterval(() => {
      if (audioEl) audioEl.volume = Math.min(1, 0.25 + (0.75 * (Date.now() - t0)) / 15000);
    }, 500);
  }
  return true;
}

function getCtx() {
  if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
  return ctx;
}

// Chamar num toque do usuário para o navegador liberar o áudio.
export function unlockAudio() {
  try {
    const c = getCtx();
    if (c.state === "suspended") c.resume();
  } catch {
    /* sem áudio */
  }
}

const usable = (tone) => (tone && tone.notes && tone.notes.length > 0 ? tone : DEFAULT_TONE);

function scheduleTone(tone, out, start) {
  const c = getCtx();
  const step = (tone.step || 280) / 1000;
  const wave = tone.wave || "triangle";
  tone.notes.forEach((freq, i) => {
    if (!freq) return;
    const when = start + i * step;
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.type = wave;
    osc.frequency.value = freq;
    const peak = wave === "square" ? 0.45 : wave === "sawtooth" ? 0.4 : 0.9;
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(peak, when + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + step * 1.5);
    osc.connect(gain);
    gain.connect(out);
    osc.start(when);
    osc.stop(when + step * 1.6);
  });
}

// Toca o toque uma vez (para a pessoa escolher).
export function previewTone(tone) {
  if (tone && tone.custom && playCustom(false, false)) return;
  try {
    const c = getCtx();
    if (c.state === "suspended") c.resume();
    const t = usable(tone);
    const out = c.createGain();
    out.connect(c.destination);
    scheduleTone(t, out, c.currentTime + 0.05);
    setTimeout(() => out.disconnect(), t.notes.length * (t.step || 280) + 800);
  } catch {
    /* sem áudio */
  }
}

export function startMelody(tone, soft = false) {
  stopMelody();
  if (tone && tone.custom && playCustom(true, soft)) return;
  try {
    const c = getCtx();
    if (c.state === "suspended") c.resume();
    const t = usable(tone);
    master = c.createGain();
    // compressor: deixa o toque mais "cheio" e alto sem estourar
    const comp = c.createDynamicsCompressor();
    master.connect(comp);
    comp.connect(c.destination);
    if (soft) {
      master.gain.setValueAtTime(0.25, c.currentTime);
      master.gain.linearRampToValueAtTime(1, c.currentTime + 15);
    }
    const loop = () => {
      if (master) scheduleTone(t, master, c.currentTime + 0.05);
    };
    loop();
    timer = setInterval(loop, t.notes.length * (t.step || 280) + 700);
  } catch {
    /* sem áudio */
  }
}

export function stopMelody() {
  stopCustom();
  if (timer !== null) clearInterval(timer);
  timer = null;
  if (master) {
    master.disconnect();
    master = null;
  }
}
