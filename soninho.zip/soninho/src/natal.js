// Natal do Soninho: dia 25 muda o tema, a mensagem do alarme e o "Ho ho ho!".
import { hasCustom } from "./customSound.js";

const PREV = "soninho:natal-preview";
export const NATAL_MSG = "Acorda, hoje é Natal! 🎁";

export const isNatalDay = (d = new Date()) => d.getMonth() === 11 && d.getDate() === 25;
export const previewOn = () => localStorage.getItem(PREV) === "1";
export function setPreview(on) {
  try {
    on ? localStorage.setItem(PREV, "1") : localStorage.removeItem(PREV);
  } catch {
    /* ignora */
  }
}
// Tema de Natal: só no dia 25 (some às 00:00 do dia 26) ou quando a pessoa pede para ver.
export const natalActive = () => isNatalDay() || previewOn();
// Véspera e dia de Natal: alarmes já saem com o "Ho ho ho!" gravado.
export const natalWindow = (d = new Date()) => d.getMonth() === 11 && (d.getDate() === 24 || d.getDate() === 25);
export const isDate25 = (date) => typeof date === "string" && date.endsWith("-12-25");

export function daysToNatal(now = new Date()) {
  let y = now.getFullYear();
  let t = new Date(y, 11, 25);
  const today = new Date(y, now.getMonth(), now.getDate());
  if (today > t) t = new Date(++y, 11, 25);
  return { days: Math.round((t - today) / 86400000), year: y };
}

// Se a pessoa não gravou o "Ho ho ho!", o celular fala.
export function startHoHoHo() {
  if (hasCustom() || !window.speechSynthesis) return () => {};
  const say = () => {
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance("Ho ho ho! Acorda, hoje é Natal!");
      u.lang = "pt-BR";
      u.volume = 1;
      u.pitch = 0.5;
      u.rate = 0.9;
      speechSynthesis.speak(u);
    } catch {
      /* sem voz */
    }
  };
  say();
  const t = setInterval(say, 12000);
  return () => {
    clearInterval(t);
    try {
      speechSynthesis.cancel();
    } catch {
      /* ignora */
    }
  };
}

let snowLayer = null;
export function setSnow(on) {
  if (!on) {
    snowLayer?.remove();
    snowLayer = null;
    return;
  }
  if (snowLayer) return;
  snowLayer = document.createElement("div");
  Object.assign(snowLayer.style, { position: "fixed", inset: "0", pointerEvents: "none", overflow: "hidden", zIndex: "45" });
  for (let i = 0; i < 22; i++) {
    const f = document.createElement("span");
    f.textContent = i % 5 === 0 ? "🎄" : "❄️";
    Object.assign(f.style, { position: "absolute", top: "-40px", left: `${Math.random() * 100}%`, fontSize: `${12 + Math.random() * 14}px`, opacity: ".8" });
    f.animate(
      [{ transform: "translate(0,0)" }, { transform: `translate(${Math.random() * 60 - 30}px,${window.innerHeight + 60}px)` }],
      { duration: 6000 + Math.random() * 7000, iterations: Infinity, delay: -Math.random() * 12000, easing: "linear" }
    );
    snowLayer.append(f);
  }
  document.body.append(snowLayer);
}
