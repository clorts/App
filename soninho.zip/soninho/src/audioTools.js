// Validação rígida + conversão de áudio/vídeo/gravação para um WAV próprio (mono, 22,05 kHz, até 30 s).
// Como o arquivo final é sempre gerado por este código, nada do arquivo original (scripts, metadados) é guardado.
export const MAX_AUDIO_BYTES = 15 * 1024 * 1024;
export const MAX_VIDEO_BYTES = 60 * 1024 * 1024;
export const MAX_SECONDS = 30;
const RATE = 22050;

const AUDIO_EXT = ["mp3", "wav", "m4a", "aac", "ogg", "oga", "opus", "webm", "3gp", "amr"];
const VIDEO_EXT = ["mp4", "m4v", "mov", "3gp", "webm"];

const ascii = (b, from, text) => [...text].every((ch, i) => b[from + i] === ch.charCodeAt(0));
// Confere os primeiros bytes: o nome do arquivo pode mentir, o conteúdo não.
function looksLikeMedia(b) {
  if (b.length < 12) return false;
  return (
    ascii(b, 0, "RIFF") || ascii(b, 0, "OggS") || ascii(b, 0, "ID3") || ascii(b, 4, "ftyp") || ascii(b, 0, "#!AMR") ||
    (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) ||
    (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)
  );
}

export async function validateFile(file) {
  const ext = (file.name.split(".").pop() || "").toLowerCase();
  const isVideo = file.type.startsWith("video/") || (!file.type.startsWith("audio/") && VIDEO_EXT.includes(ext) && ext !== "3gp" && ext !== "webm");
  const okType = file.type.startsWith("audio/") || file.type.startsWith("video/") || file.type === "";
  if (!okType || !(AUDIO_EXT.includes(ext) || VIDEO_EXT.includes(ext))) throw new Error("Formato não aceito. Use MP3, WAV, M4A, AAC, OGG, MP4, MOV ou WEBM. 🎵");
  const max = isVideo ? MAX_VIDEO_BYTES : MAX_AUDIO_BYTES;
  if (file.size === 0) throw new Error("O arquivo está vazio. 🙈");
  if (file.size > max) throw new Error(`Arquivo grande demais (máx. ${Math.round(max / 1048576)} MB). ✂️`);
  const head = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  if (!looksLikeMedia(head)) throw new Error("Esse arquivo não parece ser de áudio ou vídeo de verdade. 🚫");
}

function toWav(samples) {
  const buf = new ArrayBuffer(44 + samples.length * 2);
  const v = new DataView(buf);
  const w = (o, t) => [...t].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, "RIFF"); v.setUint32(4, 36 + samples.length * 2, true); w(8, "WAVEfmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, RATE, true); v.setUint32(28, RATE * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  w(36, "data"); v.setUint32(40, samples.length * 2, true);
  samples.forEach((s, i) => v.setInt16(44 + i * 2, Math.max(-1, Math.min(1, s)) * 32767, true));
  return new Uint8Array(buf);
}

// bytes (ArrayBuffer de áudio/vídeo/gravação) -> { b64, seconds } em WAV
export async function convertToWav(arrayBuffer, startSec = 0) {
  const AC = window.AudioContext || window.webkitAudioContext;
  const ctx = new AC();
  let decoded;
  try {
    decoded = await ctx.decodeAudioData(arrayBuffer);
  } catch {
    throw new Error("Não consegui ler o som desse arquivo. Tente MP3, M4A ou WAV. 😢");
  } finally {
    ctx.close?.();
  }
  const start = Math.min(Math.max(0, startSec), Math.max(0, decoded.duration - 1));
  const secs = Math.min(MAX_SECONDS, decoded.duration - start);
  if (!(secs >= 1)) throw new Error("O áudio precisa ter pelo menos 1 segundo. ⏱️");
  const off = new OfflineAudioContext(1, Math.floor(secs * RATE), RATE);
  const src = off.createBufferSource();
  src.buffer = decoded;
  src.connect(off.destination);
  src.start(0, start);
  const out = (await off.startRendering()).getChannelData(0);
  // normaliza o volume e dá um pequeno fade nas pontas
  let peak = 0.0001;
  for (const s of out) peak = Math.max(peak, Math.abs(s));
  const gain = Math.min(4, 0.95 / peak);
  const fade = Math.min(out.length >> 3, 800);
  const pcm = Float32Array.from(out, (s, i) => s * gain * Math.min(1, i / fade, (out.length - i) / fade));
  const bytes = toWav(pcm);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return { b64: btoa(bin), seconds: secs };
}

// Grava do microfone por até MAX_SECONDS. Devolve { stop(): Promise<ArrayBuffer> }.
export async function startRecording(onTick, onAutoStop) {
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) throw new Error("Este aparelho não consegue gravar áudio aqui. 🎙️");
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch {
    throw new Error("Sem permissão do microfone. Libere nos ajustes do celular. 🎙️");
  }
  const rec = new MediaRecorder(stream);
  const chunks = [];
  rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  const done = new Promise((resolve) => {
    rec.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      resolve(await new Blob(chunks, { type: rec.mimeType }).arrayBuffer());
    };
  });
  rec.start();
  let sec = 0;
  const timer = setInterval(() => {
    sec += 1;
    onTick(sec);
    if (sec >= MAX_SECONDS) {
      clearInterval(timer);
      if (rec.state !== "inactive") rec.stop();
      onAutoStop?.();
    }
  }, 1000);
  return { stop: () => { clearInterval(timer); if (rec.state !== "inactive") rec.stop(); return done; } };
}
