import { SHAKES_NEEDED } from "../config.js";
import { C, buttonBase, h, inputStyle } from "../ui.js";

const rand = (n) => Math.floor(Math.random() * n);
const normalize = (s) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9 ]/g, "")
    .trim()
    .replace(/\s+/g, " ");

const PHRASES = ["bom dia nuvi", "hoje vai ser um dia lindo", "eu vou levantar agora", "acordei feliz e cheio de energia"];

const msgStyle = { margin: "8px 0 0", fontSize: "14px", fontWeight: "800", color: C.candy600, minHeight: "20px" };
const okButton = (onClick) =>
  h("button", { onClick, style: { ...buttonBase, marginTop: "4px", padding: "12px 28px", borderRadius: "999px", background: C.candy500, color: C.onPink } }, "Confirmar");

function mathChallenge(onSolved) {
  const need = 2;
  let solved = 0;
  let answer = 0;
  const question = h("div", { style: { fontSize: "34px", fontWeight: "900", color: C.slate700, marginBottom: "8px" } });
  const input = h("input", {
    type: "text",
    inputmode: "numeric",
    placeholder: "?",
    style: { ...inputStyle, width: "150px", textAlign: "center", fontSize: "28px", marginBottom: "8px" },
  });
  const msg = h("p", { style: msgStyle });

  function next() {
    const a = 2 + rand(8);
    const b = 2 + rand(8);
    const c = rand(20);
    answer = a * b + c;
    question.textContent = `${a} × ${b} + ${c} = ?`;
    input.value = "";
  }
  function check() {
    if (parseInt(input.value, 10) === answer) {
      solved += 1;
      if (solved >= need) return onSolved();
      msg.textContent = `Certo! ${solved}/${need} ✨`;
      next();
    } else {
      msg.textContent = "Quase! Tente de novo 🙈";
      input.value = "";
    }
  }
  input.addEventListener("keydown", (e) => e.key === "Enter" && check());
  next();
  return { el: h("div", {}, question, input, msg, okButton(check)), cleanup() {} };
}

function phraseChallenge(onSolved) {
  const phrase = PHRASES[rand(PHRASES.length)];
  const input = h("input", { type: "text", placeholder: "digite a frase", style: { ...inputStyle, textAlign: "center", marginBottom: "8px" } });
  const msg = h("p", { style: msgStyle });
  function check() {
    if (normalize(input.value) === normalize(phrase)) return onSolved();
    msg.textContent = "Não é bem essa... confira a frase 🙈";
  }
  input.addEventListener("keydown", (e) => e.key === "Enter" && check());
  const el = h(
    "div",
    {},
    h("div", { style: { fontSize: "22px", fontWeight: "900", color: C.slate700, marginBottom: "10px" } }, `“${phrase}”`),
    input,
    msg,
    okButton(check)
  );
  return { el, cleanup() {} };
}

function shakeChallenge(onSolved, onFallback, onProgress) {
  let count = 0;
  let last = 0;
  let gotEvent = false;
  const msg = h("p", { style: msgStyle });
  const fallback = h(
    "button",
    {
      onClick: onFallback,
      style: { ...buttonBase, display: "none", marginTop: "8px", padding: "10px 20px", borderRadius: "999px", background: C.glass8, color: C.slate500, fontSize: "14px" },
    },
    "Não balança? Usar estrelinhas ⭐"
  );

  function onMotion(e) {
    gotEvent = true;
    const g = e.accelerationIncludingGravity;
    if (!g) return;
    const magnitude = Math.sqrt((g.x || 0) ** 2 + (g.y || 0) ** 2 + (g.z || 0) ** 2);
    const now = Date.now();
    if (Math.abs(magnitude - 9.81) > 9 && now - last > 350) {
      last = now;
      count += 1;
      onProgress(`Balance o celular! ${count}/${SHAKES_NEEDED} 📳`);
      if (count >= SHAKES_NEEDED) onSolved();
    }
  }
  window.addEventListener("devicemotion", onMotion);
  const timer = setTimeout(() => {
    if (!gotEvent) fallback.style.display = "inline-block";
  }, 3000);

  return {
    el: h("div", {}, h("div", { style: { fontSize: "56px" } }, "📳"), msg, fallback),
    cleanup() {
      window.removeEventListener("devicemotion", onMotion);
      clearTimeout(timer);
    },
  };
}

export const HINTS = {
  math: "Resolva 2 continhas para acordar! 🧮",
  phrase: "Digite a frase para acordar ✍️",
  shake: `Balance o celular! 0/${SHAKES_NEEDED} 📳`,
};

export function startChallenge(mode, { onSolved, onFallback, onProgress }) {
  if (mode === "math") return mathChallenge(onSolved);
  if (mode === "phrase") return phraseChallenge(onSolved);
  return shakeChallenge(onSolved, onFallback, onProgress);
}
