import { TONES, toneById } from "../tones.js";
import { previewTone } from "../sound.js";
import { C, buttonBase, h, modal } from "../ui.js";

// Lista de toques: tocar num toque escolhe e já deixa ouvir.
export function openTonePicker({ current, onPick }) {
  let selected = toneById(current).id;
  const close = () => overlay.remove();

  const rows = TONES.map((tone) =>
    h(
      "button",
      {
        onClick: () => {
          selected = tone.id;
          onPick(tone.id);
          previewTone(tone);
          paint();
        },
        style: { ...buttonBase, display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", padding: "14px 16px", borderRadius: "16px", marginBottom: "8px", textAlign: "left" },
      },
      h("span", {}, tone.system ? `📱 ${tone.name}` : `🎵 ${tone.name}`),
      h("span", { "data-check": "1" }, "")
    )
  );

  function paint() {
    rows.forEach((row, i) => {
      const on = TONES[i].id === selected;
      row.style.background = on ? C.candy500 : C.candy100;
      row.style.color = on ? C.onPink : C.candy600;
      row.lastChild.textContent = on ? "✓" : "";
    });
  }
  paint();

  const body = h(
    "div",
    {},
    ...rows,
    h("button", { onClick: close, style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginTop: "8px", background: C.slate100, color: C.slate500 } }, "Pronto")
  );
  const overlay = modal("Escolher toque 🎵", body, close);
  document.body.append(overlay);
}
