// Musiquinha fofa gerada por código (sem arquivo de áudio).
const NOTES = [523.25, 659.25, 783.99, 659.25, 880.0, 783.99, 659.25, 587.33];

let ctx = null;
let master = null;
let timer = null;

function getCtx() {
  if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
  return ctx;
}

// Chamar num toque do usuário para o navegador liberar o áudio.
export function unlockAudio() {
  try {
    const c = getCtx();
    if (c.state === "suspended") c.resume();
  } catch {
    /* sem áudio */
  }
}

function playNote(freq, when) {
  if (!ctx || !master) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = "triangle";
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(0.0001, when);
  gain.gain.exponentialRampToValueAtTime(0.25, when + 0.03);
  gain.gain.exponentialRampToValueAtTime(0.0001, when + 0.4);
  osc.connect(gain);
  gain.connect(master);
  osc.start(when);
  osc.stop(when + 0.45);
}

export function startMelody() {
  stopMelody();
  try {
    const c = getCtx();
    if (c.state === "suspended") c.resume();
    master = c.createGain();
    master.connect(c.destination);
    const loop = () => {
      if (!master) return;
      const t = c.currentTime;
      NOTES.forEach((n, i) => playNote(n, t + i * 0.28));
    };
    loop();
    timer = setInterval(loop, NOTES.length * 280 + 400);
  } catch {
    /* sem áudio */
  }
}

export function stopMelody() {
  if (timer !== null) clearInterval(timer);
  timer = null;
  if (master) {
    master.disconnect();
    master = null;
  }
}
