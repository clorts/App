import { anim } from "../ui.js";

const NS = "http://www.w3.org/2000/svg";

function s(tag, attrs = {}, ...kids) {
  const el = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  kids.forEach((k) => el.append(k));
  return el;
}

// Nuvi, a nuvem mascote do Soninho ☁️  (mood: "sleeping" | "happy" | "ringing")
export function Mascot({ mood = "happy", size = 180 } = {}) {
  const svg = s("svg", {
    viewBox: "0 0 200 150",
    width: size,
    height: (size * 150) / 200,
    role: "img",
    "aria-label": "Nuvi, a nuvem mascote",
  });
  svg.style.overflow = "visible";

  svg.append(
    s("ellipse", { cx: 100, cy: 140, rx: 55, ry: 6, fill: "#9ad0f5", opacity: ".35" }),
    s(
      "g",
      { fill: "#ffffff", stroke: "#9ad0f5", "stroke-width": 4 },
      s("circle", { cx: 60, cy: 85, r: 34 }),
      s("circle", { cx: 100, cy: 62, r: 42 }),
      s("circle", { cx: 142, cy: 85, r: 34 }),
      s("rect", { x: 60, y: 85, width: 82, height: 34, rx: 17 })
    ),
    s(
      "g",
      { fill: "#ffffff" },
      s("circle", { cx: 60, cy: 85, r: 31 }),
      s("circle", { cx: 100, cy: 62, r: 39 }),
      s("circle", { cx: 142, cy: 85, r: 31 }),
      s("rect", { x: 62, y: 87, width: 78, height: 30, rx: 15 })
    )
  );

  if (mood === "sleeping") {
    svg.append(
      s(
        "g",
        { stroke: "#5b6b8c", "stroke-width": 4, "stroke-linecap": "round", fill: "none" },
        s("path", { d: "M72 88 q8 8 16 0" }),
        s("path", { d: "M112 88 q8 8 16 0" }),
        s("path", { d: "M94 102 q6 5 12 0" })
      )
    );
  } else {
    const ringing = mood === "ringing";
    svg.append(
      s(
        "g",
        {},
        s("circle", { cx: 80, cy: 88, r: 7, fill: "#3b4565" }),
        s("circle", { cx: 120, cy: 88, r: 7, fill: "#3b4565" }),
        s("circle", { cx: 82.5, cy: 85.5, r: 2.5, fill: "#fff" }),
        s("circle", { cx: 122.5, cy: 85.5, r: 2.5, fill: "#fff" }),
        s("path", {
          d: ringing ? "M90 99 q10 14 20 0 z" : "M92 100 q8 9 16 0",
          fill: ringing ? "#ff6aa2" : "none",
          stroke: "#3b4565",
          "stroke-width": 3.5,
          "stroke-linecap": "round",
        })
      )
    );
  }

  svg.append(
    s("ellipse", { cx: 66, cy: 100, rx: 9, ry: 6, fill: "#ff8fb8", opacity: ".55" }),
    s("ellipse", { cx: 134, cy: 100, rx: 9, ry: 6, fill: "#ff8fb8", opacity: ".55" })
  );

  if (mood === "sleeping") {
    const z1 = s("text", { x: 150, y: 40, "font-size": 18 });
    z1.textContent = "z";
    const z2 = s("text", { x: 164, y: 26, "font-size": 24 });
    z2.textContent = "Z";
    anim(z1, "twinkle");
    anim(z2, "twinkle");
    svg.append(s("g", { fill: "#9ad0f5", "font-weight": 900, "font-family": "Nunito, sans-serif" }, z1, z2));
  }

  return anim(svg, mood === "ringing" ? "wiggle" : "float");
}
