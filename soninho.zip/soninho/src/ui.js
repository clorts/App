// Ferramentas de interface: criar elementos, cores e animações — tudo em JavaScript.
export const C = {
  candy50: "#fff5f9",
  candy100: "#ffe4ef",
  candy200: "#ffc7de",
  candy400: "#ff8fb8",
  candy500: "#ff6aa2",
  candy600: "#e84d8a",
  skySoft: "#dff1ff",
  skyDeep: "#9ad0f5",
  slate700: "#334155",
  slate600: "#475569",
  slate500: "#64748b",
  slate400: "#94a3b8",
  slate300: "#cbd5e1",
  slate100: "#f1f5f9",
  white: "#ffffff",
};

export const FONT = "Nunito, ui-rounded, system-ui, sans-serif";

export function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(props ?? {})) {
    if (key === "style") Object.assign(el.style, value);
    else if (key.startsWith("on")) el.addEventListener(key.slice(2).toLowerCase(), value);
    else if (key === "value") el.value = value;
    else if (value === true) el.setAttribute(key, "");
    else if (value !== false && value != null) el.setAttribute(key, value);
  }
  for (const child of children.flat()) {
    if (child == null || child === false) continue;
    el.append(child.nodeType ? child : document.createTextNode(String(child)));
  }
  return el;
}

const KEYFRAMES = {
  float: [{ transform: "translateY(0)" }, { transform: "translateY(-10px)" }, { transform: "translateY(0)" }],
  wiggle: [{ transform: "rotate(-4deg)" }, { transform: "rotate(4deg)" }, { transform: "rotate(-4deg)" }],
  pop: [{ transform: "scale(.6)", opacity: 0 }, { transform: "scale(1)", opacity: 1 }],
  twinkle: [{ opacity: 0.4 }, { opacity: 1 }, { opacity: 0.4 }],
};
const TIMING = {
  float: { duration: 3000, iterations: Infinity, easing: "ease-in-out" },
  wiggle: { duration: 400, iterations: Infinity, easing: "ease-in-out" },
  pop: { duration: 250, easing: "ease-out" },
  twinkle: { duration: 2000, iterations: Infinity, easing: "ease-in-out" },
};

export function anim(el, name) {
  if (el.animate) el.animate(KEYFRAMES[name], TIMING[name]);
  return el;
}

export const buttonBase = {
  border: "none",
  cursor: "pointer",
  fontFamily: "inherit",
  fontWeight: "900",
  fontSize: "16px",
};

export const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  padding: "12px",
  borderRadius: "16px",
  border: "none",
  outline: "none",
  background: C.candy50,
  fontFamily: "inherit",
  fontWeight: "700",
  fontSize: "16px",
  color: C.slate700,
  marginBottom: "12px",
};

// Fundo escuro + cartão branco (usado no formulário e na conta).
export function modal(title, body, onClose) {
  const card = h(
    "div",
    {
      onClick: (e) => e.stopPropagation(),
      style: {
        width: "100%",
        maxWidth: "448px",
        boxSizing: "border-box",
        background: C.white,
        borderRadius: "32px",
        padding: "24px",
        boxShadow: "0 25px 50px -12px rgba(0,0,0,.25)",
      },
    },
    h("h2", { style: { margin: "0 0 16px", textAlign: "center", fontSize: "24px", fontWeight: "900", color: C.candy600 } }, title),
    body
  );
  anim(card, "pop");
  return h(
    "div",
    {
      onClick: onClose,
      style: {
        position: "fixed",
        inset: "0",
        zIndex: "40",
        display: "flex",
        alignItems: window.innerWidth >= 640 ? "center" : "flex-end",
        justifyContent: "center",
        padding: "12px",
        background: "rgba(15,23,42,.3)",
      },
    },
    card
  );
}
