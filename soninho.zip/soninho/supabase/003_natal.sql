-- Rode no SQL Editor do Supabase (uma vez). Sem isso o app funciona, mas dias marcados e toques não ficam na conta.
alter table public.soninho_alarms add column if not exists date text;
alter table public.soninho_alarms add column if not exists tone text;
