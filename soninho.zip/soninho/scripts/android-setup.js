// Roda depois de "npx cap add android": libera permissões de alarme e cria o ícone da notificação.
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const manifestPath = join("android", "app", "src", "main", "AndroidManifest.xml");
if (!existsSync(manifestPath)) throw new Error("Rode 'npx cap add android' antes deste script.");

const permissions = [
  "android.permission.POST_NOTIFICATIONS",
  "android.permission.SCHEDULE_EXACT_ALARM",
  "android.permission.USE_EXACT_ALARM",
  "android.permission.RECEIVE_BOOT_COMPLETED",
  "android.permission.VIBRATE",
  "android.permission.WAKE_LOCK",
];

let manifest = readFileSync(manifestPath, "utf8");
const missing = permissions.filter((p) => !manifest.includes(`"${p}"`));
if (missing.length > 0) {
  const lines = missing.map((p) => `    <uses-permission android:name="${p}" />`).join("\n");
  manifest = manifest.replace("<application", `${lines}\n\n    <application`);
  writeFileSync(manifestPath, manifest);
}

// Ícone de nuvem (branco) para a barra de notificações.
const drawableDir = join("android", "app", "src", "main", "res", "drawable");
mkdirSync(drawableDir, { recursive: true });
const cloud = [
  '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
  '    android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">',
  '  <path android:fillColor="#FFFFFFFF"',
  '      android:pathData="M19.35,10.04C18.67,6.59 15.64,4 12,4 9.11,4 6.6,5.64 5.35,8.04 2.34,8.36 0,10.91 0,14c0,3.31 2.69,6 6,6h13c2.76,0 5,-2.24 5,-5 0,-2.64 -2.05,-4.78 -4.65,-4.96z" />',
  "</vector>",
  "",
].join("\n");
writeFileSync(join(drawableDir, "ic_stat_soninho.xml"), cloud);

console.log("Android configurado ☁️");
