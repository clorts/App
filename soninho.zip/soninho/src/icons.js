// Ícones (SVG) no lugar dos emojis: todo emoji que aparece na tela vira um ícone que acompanha a cor do texto.
const P = (d) => `<path d="${d}"/>`;
const CIR = (x, y, r) => `<circle cx="${x}" cy="${y}" r="${r}"/>`;
const DOT = (x, y) => `<path d="M${x} ${y}h.01"/>`;

const ICONS = {
  cloud: P("M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"),
  mic: P("M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z M19 10v2a7 7 0 0 1-14 0v-2 M12 19v3"),
  tree: P("M12 2 7 9h3l-4 6h4l-3 5h12l-3-5h4l-4-6h3z M12 20v2"),
  music: P("M9 18V5l12-2v13") + CIR(6, 18, 3) + CIR(18, 16, 3),
  heart: P("M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"),
  gift: P("M20 12v10H4V12 M2 7h20v5H2z M12 22V7 M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"),
  moon: P("M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"),
  star: P("m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"),
  hat: P("M4 19c0-8 4-15 12-15 M3 19h18v3H3z") + CIR(17, 4, 2),
  eyeoff: P("M9.88 9.88a3 3 0 1 0 4.24 4.24 M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68 M6.61 6.61A13.52 13.52 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61 M2 2l20 20"),
  mail: P("M3 4h18v16H3z M21 6l-9 7-9-7"),
  vibrate: P("M8 3h8v18H8z M4 8v8 M20 8v8"),
  sad: CIR(12, 12, 10) + P("M16 16s-1.5-2-4-2-4 2-4 2") + DOT(9, 9) + DOT(15, 9),
  snow: P("M2 12h20 M12 2v20 M20 16l-4-4 4-4 M4 8l4 4-4 4 M16 4l-4 4-4-4 M8 20l4-4 4 4"),
  sparkles: P("m12 3 1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z M19 16l.7 1.8 1.8.7-1.8.7L19 21l-.7-1.8-1.8-.7 1.8-.7z"),
  sun: CIR(12, 12, 4) + P("M12 2v2 M12 20v2 M4.93 4.93l1.41 1.41 M17.66 17.66l1.41 1.41 M2 12h2 M20 12h2 M6.34 17.66l-1.41 1.41 M19.07 4.93l-1.41 1.41"),
  trash: P("M3 6h18 M19 6l-1 14H6L5 6 M8 6V4h8v2 M10 11v6 M14 11v6"),
  flower: CIR(12, 12, 2.5) + CIR(12, 6, 3) + CIR(12, 18, 3) + CIR(6, 12, 3) + CIR(18, 12, 3),
  key: P("m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.78 7.78 5.5 5.5 0 0 1 7.78-7.78zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4"),
  check: P("M20 6 9 17l-5-5"),
  calc: P("M5 2h14v20H5z M8 6h8") + DOT(8, 11) + DOT(12, 11) + DOT(16, 11) + DOT(8, 15) + DOT(12, 15) + DOT(16, 15) + DOT(8, 19) + DOT(12, 19) + DOT(16, 19),
  pen: P("M12 20h9 M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"),
  alarm: CIR(12, 13, 8) + P("M12 9v4l2 2 M5 3 2 6 M22 6l-3-3"),
  sliders: P("M4 21v-7 M4 10V3 M12 21v-9 M12 8V3 M20 21v-5 M20 12V3 M1 14h6 M9 8h6 M17 16h6"),
  cookie: P("M21 12a9 9 0 1 1-9-9 3 3 0 0 0 4 4 3 3 0 0 0 5 5z") + DOT(8, 10) + DOT(10, 16) + DOT(15, 14),
  scissors: CIR(6, 6, 3) + CIR(6, 18, 3) + P("M20 4 8.12 15.88 M14.47 14.48 20 20 M8.12 8.12 12 12"),
  ban: CIR(12, 12, 10) + P("m4.9 4.9 14.2 14.2"),
  calendar: P("M3 4h18v18H3z M16 2v4 M8 2v4 M3 10h18"),
  save: P("M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z M17 21v-8H7v8 M7 3v5h8"),
  download: P("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4 M7 10l5 5 5-5 M12 15V3"),
  upload: P("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4 M17 8l-5-5-5 5 M12 3v12"),
  image: P("M3 3h18v18H3z") + CIR(8.5, 8.5, 1.5) + P("m21 15-5-5L5 21"),
  cat: P("M4 4l4 3h8l4-3v9a8 8 0 0 1-16 0z") + DOT(9, 12) + DOT(15, 12) + P("M10 15.5c1 .6 3 .6 4 0"),
  bear: CIR(6, 6, 2.5) + CIR(18, 6, 2.5) + CIR(12, 13, 8) + DOT(9, 12) + DOT(15, 12) + P("M10.5 16h3"),
  eye: P("M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z") + CIR(12, 12, 3),
  zzz: P("M4 4h6L4 12h6 M14 10h5l-5 6h5"),
  folder: P("M3 5h6l2 3h10v12H3z"),
  phone: P("M7 2h10v20H7z M12 18h.01"),
  lock: P("M5 11h14v10H5z M8 11V7a4 4 0 0 1 8 0v4"),
  doc: P("M14 2H6v20h12V6z M14 2v4h4 M9 13h6 M9 17h6"),
  bell: P("M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9 M13.7 21a2 2 0 0 1-3.4 0"),
};

const MAP = {
  "☁": "cloud", "🎙": "mic", "🎄": "tree", "🎵": "music", "💖": "heart", "🎁": "gift", "🌙": "moon", "⭐": "star", "🎅": "hat",
  "🙈": "eyeoff", "💌": "mail", "📳": "vibrate", "😢": "sad", "❄": "snow", "✨": "sparkles", "☀": "sun", "🌞": "sun", "🗑": "trash",
  "🌷": "flower", "🌼": "flower", "🔑": "key", "✅": "check", "✓": "check", "🧮": "calc", "✍": "pen", "⏰": "alarm", "⚙": "sliders",
  "🍪": "cookie", "✂": "scissors", "🚫": "ban", "📅": "calendar", "💾": "save", "📲": "download", "⬇": "download", "📤": "upload",
  "🖼": "image", "🐱": "cat", "🐻": "bear", "👀": "eye", "😴": "zzz", "💤": "zzz", "📁": "folder", "📱": "phone", "🔒": "lock",
  "📜": "doc", "🔔": "bell", "🎉": "sparkles",
};

const RE = new RegExp(`(${Object.keys(MAP).join("|")})\\uFE0F?`, "gu");
const STRIP = new RegExp(`(?:${Object.keys(MAP).join("|")})\\uFE0F?\\s?`, "gu");
const SKIP = new Set(["SCRIPT", "STYLE", "TEXTAREA", "OPTION", "TITLE"]);
const ATTRS = ["placeholder", "title", "aria-label", "alt"];

export const stripEmoji = (t) => String(t).replace(STRIP, "").trim();

export function icon(name, size = "1em") {
  const el = document.createElement("span");
  el.className = "si";
  Object.assign(el.style, { display: "inline-flex", verticalAlign: "-0.15em", width: size, height: size, flex: "none" });
  el.innerHTML = `<svg viewBox="0 0 24 24" width="100%" height="100%" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.cloud}</svg>`;
  return el;
}

function fix(node) {
  if (node.nodeType === 3) {
    const tag = node.parentNode && node.parentNode.nodeName;
    if (!node.nodeValue || tag === "SVG" || tag === "text") return;
    if (!RE.test(node.nodeValue)) return;
    RE.lastIndex = 0;
    if (SKIP.has(tag)) {
      node.nodeValue = stripEmoji(node.nodeValue);
      return;
    }
    const parts = node.nodeValue.split(RE);
    const frag = document.createDocumentFragment();
    parts.forEach((p, i) => {
      if (i % 2) frag.append(icon(MAP[p]));
      else if (p) frag.append(document.createTextNode(p));
    });
    node.replaceWith(frag);
    return;
  }
  if (node.nodeType !== 1) return;
  if (node.nodeName === "svg" || node.classList?.contains("si")) return;
  for (const a of ATTRS) {
    const v = node.getAttribute?.(a);
    if (v && RE.test(v)) node.setAttribute(a, stripEmoji(v));
    RE.lastIndex = 0;
  }
  [...node.childNodes].forEach(fix);
}

export function startIcons() {
  document.title = stripEmoji(document.title);
  fix(document.body);
  new MutationObserver((list) => {
    for (const m of list) {
      if (m.type === "childList") m.addedNodes.forEach(fix);
      else if (m.type === "characterData") fix(m.target);
      else if (m.type === "attributes") fix(m.target);
    }
  }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
}
