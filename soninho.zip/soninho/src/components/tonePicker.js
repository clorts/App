import { hasCustom } from "../customSound.js";
import { TONES, toneById } from "../tones.js";
import { previewTone, stopMelody } from "../sound.js";
import { C, buttonBase, h, modal } from "../ui.js";
import { openSoundMaker } from "./soundMaker.js";

// Lista de toques: tocar num toque escolhe e já deixa ouvir.
export function openTonePicker({ current, onPick }) {
  let selected = toneById(current).id;
  const close = () => {
    stopMelody();
    overlay.remove();
  };
  const body = h("div");
  const overlay = modal("Escolher toque 🎵", body, close);

  function render() {
    const list = TONES.filter((t) => !t.custom || hasCustom());
    const rows = list.map((tone) => {
      const on = tone.id === selected;
      return h(
        "button",
        {
          onClick: () => {
            selected = tone.id;
            onPick(tone.id);
            previewTone(tone);
            render();
          },
          style: { ...buttonBase, display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", padding: "14px 16px", borderRadius: "16px", marginBottom: "8px", textAlign: "left", background: on ? C.candy500 : C.candy100, color: on ? C.onPink : C.candy600 },
        },
        h("span", {}, tone.system ? `📱 ${tone.name}` : tone.custom ? `🎙️ ${tone.name}` : `🎵 ${tone.name}`),
        h("span", {}, on ? "✓" : "")
      );
    });
    const mine = h(
      "button",
      {
        onClick: () =>
          openSoundMaker({
            onSaved: () => {
              if (hasCustom()) {
                selected = "custom";
                onPick("custom");
              } else if (selected === "custom") {
                selected = TONES[0].id;
                onPick(selected);
              }
              render();
            },
          }),
        style: { ...buttonBase, width: "100%", padding: "14px 16px", borderRadius: "16px", marginBottom: "8px", background: C.skySoft, color: C.slate600 },
      },
      hasCustom() ? "🎙️ Trocar meu áudio" : "🎙️ Gravar ou escolher meu áudio"
    );
    const done = h("button", { onClick: close, style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginTop: "8px", background: C.slate100, color: C.slate500 } }, "Pronto");
    body.replaceChildren(...rows, mine, done);
  }
  render();
  document.body.append(overlay);
}
