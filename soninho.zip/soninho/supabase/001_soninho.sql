create table if not exists public.soninho_alarms (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade default auth.uid(), label text not null default 'Acordar', time text not null, days int[] not null default '{}', enabled boolean not null default true, created_at timestamptz not null default now());
alter table public.soninho_alarms enable row level security;
create policy "soninho_select_own" on public.soninho_alarms for select to authenticated using (auth.uid() = user_id);
create policy "soninho_insert_own" on public.soninho_alarms for insert to authenticated with check (auth.uid() = user_id);
create policy "soninho_update_own" on public.soninho_alarms for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "soninho_delete_own" on public.soninho_alarms for delete to authenticated using (auth.uid() = user_id);
