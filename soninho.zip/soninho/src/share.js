import { SHARE_URL } from "./config.js";

export function baseUrl() {
  if (SHARE_URL) return SHARE_URL.replace(/\/$/, "");
  const ok = location.protocol.startsWith("http") && !/^(localhost|127\.|192\.168\.)/.test(location.hostname);
  return ok ? location.origin : "";
}

// Abre o compartilhar do celular; sem isso, abre o WhatsApp com o texto pronto.
export async function shareText(text, url) {
  const full = url ? `${text} ${url}` : text;
  try {
    if (navigator.share) return void (await navigator.share({ text, ...(url ? { url } : {}) }));
  } catch (e) {
    if (e && e.name === "AbortError") return;
  }
  window.open(`https://wa.me/?text=${encodeURIComponent(full)}`, "_blank");
}

export const shareApp = () => shareText("Estou usando o Soninho ☁️, um despertador fofo que acorda com carinho! Baixa aí:", baseUrl());
