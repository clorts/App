# Soninho ☁️ — Despertador Fofo

JavaScript puro + Supabase + Capacitor (APK). Sem arquivos .html/.css: a página é gerada pelo `build.js`
e todo o visual é feito em JavaScript.

## Gerar o APK (pelo GitHub, sem computador)
1. Crie um repositório no GitHub e envie este zip (ou os arquivos).
2. Crie o arquivo `.github/workflows/apk.yml` (já vem neste projeto; se enviou só o zip, crie esse arquivo colando o conteúdo).
3. Aba **Actions** → "Gerar APK" → espere ficar verde (uns 5-8 min).
4. Aba **Releases** (página inicial do repositório) → baixe `soninho.apk` e instale.

## Netlify (versão site)
Build command: `node build.js` — Publish directory: `dist`.

## Testar no computador
`node build.js && node serve.js` e abra http://localhost:5173

## Supabase
URL e chave publishable ficam em `src/config.js`. A tabela já foi criada (supabase/001_soninho.sql).
Nunca coloque a chave secret neste projeto.
