import { DAY_LABELS } from "../config.js";
import * as settings from "../settings.js";
import { toneById } from "../tones.js";
import { openTonePicker } from "./tonePicker.js";
import { C, buttonBase, h, inputStyle, modal } from "../ui.js";

export function openAlarmForm({ onSave }) {
  let days = [];
  let toneId = settings.get().tone;
  const close = () => overlay.remove();

  const timeInput = h("input", {
    type: "time",
    value: "07:00",
    style: { ...inputStyle, background: C.skySoft, textAlign: "center", fontSize: "48px", fontWeight: "900", padding: "16px", marginBottom: "16px" },
  });
  const labelInput = h("input", {
    type: "text",
    maxlength: "30",
    placeholder: "Nome (ex: Bom dia, sol!)",
    style: { ...inputStyle, marginBottom: "16px" },
  });

  const toneBtn = h("button", {
    onClick: () =>
      openTonePicker({
        current: toneId,
        onPick: (id) => {
          toneId = id;
          paintTone();
        },
      }),
    style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginBottom: "16px", background: C.candy100, color: C.candy600 },
  });
  const paintTone = () => (toneBtn.textContent = `🎵 Toque: ${toneById(toneId).name}`);
  paintTone();

  const repeatText = h("div", {
    style: { marginBottom: "4px", fontSize: "12px", fontWeight: "800", textTransform: "uppercase", letterSpacing: ".05em", color: C.slate400 },
  });
  const dayButtons = DAY_LABELS.map((label, d) =>
    h(
      "button",
      {
        onClick: () => {
          days = days.includes(d) ? days.filter((x) => x !== d) : [...days, d].sort();
          paintDays();
        },
        style: { ...buttonBase, width: "40px", height: "40px", borderRadius: "999px", transition: "background .15s" },
      },
      label
    )
  );

  function paintDays() {
    repeatText.textContent = days.length === 0 ? "Repetir (só uma vez)" : "Repetir";
    dayButtons.forEach((btn, d) => {
      const on = days.includes(d);
      btn.style.background = on ? C.candy500 : C.candy100;
      btn.style.color = on ? C.onPink : C.candy500;
    });
  }
  paintDays();

  const body = h(
    "div",
    {},
    timeInput,
    labelInput,
    toneBtn,
    repeatText,
    h("div", { style: { display: "flex", justifyContent: "space-between", marginBottom: "20px" } }, dayButtons),
    h(
      "div",
      { style: { display: "flex", gap: "12px" } },
      h("button", { onClick: close, style: { ...buttonBase, flex: "1", padding: "12px", borderRadius: "16px", background: C.slate100, color: C.slate500 } }, "Cancelar"),
      h(
        "button",
        {
          onClick: () => {
            onSave({ time: timeInput.value || "07:00", label: labelInput.value.trim() || "Acordar", days, tone: toneId });
            close();
          },
          style: { ...buttonBase, flex: "1", padding: "12px", borderRadius: "16px", background: C.candy500, color: C.onPink, boxShadow: "0 10px 15px -3px rgba(255,199,222,.8)" },
        },
        "Salvar"
      )
    )
  );

  const overlay = modal("Novo despertar 🌷", body, close);
  document.body.append(overlay);
}
