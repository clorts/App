import { get as getSettings } from "../settings.js";
import { noelSeason } from "../natal.js";
import { anim } from "../ui.js";

const NS = "http://www.w3.org/2000/svg";

function s(tag, attrs = {}, ...kids) {
  const el = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  kids.forEach((k) => el.append(k));
  return el;
}

// Até o dia 25 de dezembro só existem os pets de Noel; depois voltam os normais.
export const MASCOTS = noelSeason()
  ? [
      { value: "nuvi", label: "Nuvem Noel" },
      { value: "gatinho", label: "Gatinho Noel" },
      { value: "ursinho", label: "Ursinho Noel" },
    ]
  : [
      { value: "nuvi", label: "Nuvem" },
      { value: "gatinho", label: "Gatinho" },
      { value: "ursinho", label: "Ursinho" },
    ];
export const SKINS = ["nuvi-noel", "gatinho-noel", "ursinho-noel"];

// Árvore de Natal e presentes que ficam atrás dos pets de Noel.
function natalScenery() {
  const svg = s("svg", { viewBox: "0 0 200 150", "aria-hidden": "true" });
  Object.assign(svg.style, { position: "absolute", left: "0", width: "100%", top: "-26%", height: "126%", overflow: "visible", pointerEvents: "none" });
  const tier = (pts) => s("polygon", { points: pts, fill: "#2f8f55", stroke: "#1f6b3c", "stroke-width": 3, "stroke-linejoin": "round" });
  svg.append(
    s("rect", { x: 92, y: 124, width: 16, height: 18, rx: 3, fill: "#8a5a35" }),
    tier("100,6 60,52 140,52"),
    tier("100,30 48,86 152,86"),
    tier("100,58 36,124 164,124"),
    s("polygon", { points: "100,0 103,7 110,8 105,13 106,20 100,16 94,20 95,13 90,8 97,7", fill: "#ffd54a" }),
    s("circle", { cx: 84, cy: 70, r: 5, fill: "#e8404f" }),
    s("circle", { cx: 118, cy: 96, r: 5, fill: "#ffd54a" }),
    s("circle", { cx: 70, cy: 108, r: 5, fill: "#9ad0f5" }),
    s("circle", { cx: 128, cy: 66, r: 4, fill: "#ff8fb8" }),
    // presentes
    s("rect", { x: 10, y: 112, width: 34, height: 28, rx: 4, fill: "#e8404f" }),
    s("rect", { x: 24, y: 112, width: 6, height: 28, fill: "#ffd54a" }),
    s("rect", { x: 10, y: 123, width: 34, height: 6, fill: "#ffd54a" }),
    s("rect", { x: 158, y: 120, width: 30, height: 22, rx: 4, fill: "#4a8fd6" }),
    s("rect", { x: 170, y: 120, width: 6, height: 22, fill: "#fff" }),
    s("rect", { x: 158, y: 128, width: 30, height: 5, fill: "#fff" })
  );
  return svg;
}

// Skins de Natal: imagens com fundo transparente.
function skinMascot(which, mood, size) {
  const wrap = document.createElement("div");
  Object.assign(wrap.style, { position: "relative", width: `${size}px`, height: `${(size * 3) / 4}px`, display: "flex", alignItems: "center", justifyContent: "center" });
  const img = new Image();
  img.alt = "Mascote do Soninho";
  img.src = new URL(`../assets/skins/${which}.png`, import.meta.url).href;
  Object.assign(img.style, { maxWidth: "100%", maxHeight: "100%", objectFit: "contain" });
  img.style.position = "relative";
  wrap.append(natalScenery(), img);
  if (mood === "sleeping") {
    img.style.transform = "rotate(-4deg)";
    img.style.filter = "brightness(.96)";
    const z = document.createElement("span");
    z.textContent = "z Z";
    Object.assign(z.style, { position: "absolute", right: "0", top: "0", fontWeight: "900", fontSize: "22px", color: "#9ad0f5" });
    anim(z, "twinkle");
    wrap.append(z);
  }
  return anim(wrap, mood === "ringing" ? "wiggle" : "float");
}

function cloudBody() {
  return [
    s("g", { fill: "#ffffff", stroke: "#9ad0f5", "stroke-width": 4 },
      s("circle", { cx: 60, cy: 85, r: 34 }),
      s("circle", { cx: 100, cy: 62, r: 42 }),
      s("circle", { cx: 142, cy: 85, r: 34 }),
      s("rect", { x: 60, y: 85, width: 82, height: 34, rx: 17 })),
    s("g", { fill: "#ffffff" },
      s("circle", { cx: 60, cy: 85, r: 31 }),
      s("circle", { cx: 100, cy: 62, r: 39 }),
      s("circle", { cx: 142, cy: 85, r: 31 }),
      s("rect", { x: 62, y: 87, width: 78, height: 30, rx: 15 })),
  ];
}

function catBody() {
  const fur = "#ffbf80";
  const dark = "#e89a55";
  const ear = { fill: fur, stroke: dark, "stroke-width": 4, "stroke-linejoin": "round" };
  return [
    s("polygon", { points: "54,66 58,22 92,50", ...ear }),
    s("polygon", { points: "146,66 142,22 108,50", ...ear }),
    s("polygon", { points: "62,58 64,36 82,52", fill: "#ffb3cf" }),
    s("polygon", { points: "138,58 136,36 118,52", fill: "#ffb3cf" }),
    s("ellipse", { cx: 100, cy: 92, rx: 54, ry: 46, fill: fur, stroke: dark, "stroke-width": 4 }),
    s("g", { stroke: dark, "stroke-width": 3, "stroke-linecap": "round", fill: "none" },
      s("path", { d: "M40 96 l18 3" }),
      s("path", { d: "M40 108 l18 -3" }),
      s("path", { d: "M160 96 l-18 3" }),
      s("path", { d: "M160 108 l-18 -3" })),
  ];
}

function bearBody() {
  const fur = "#c8966a";
  const dark = "#a8754a";
  return [
    s("circle", { cx: 56, cy: 54, r: 20, fill: fur, stroke: dark, "stroke-width": 4 }),
    s("circle", { cx: 144, cy: 54, r: 20, fill: fur, stroke: dark, "stroke-width": 4 }),
    s("circle", { cx: 56, cy: 54, r: 10, fill: "#f0c9a5" }),
    s("circle", { cx: 144, cy: 54, r: 10, fill: "#f0c9a5" }),
    s("ellipse", { cx: 100, cy: 92, rx: 54, ry: 48, fill: fur, stroke: dark, "stroke-width": 4 }),
    s("ellipse", { cx: 100, cy: 108, rx: 22, ry: 15, fill: "#f0d3b3" }),
    s("ellipse", { cx: 100, cy: 97, rx: 7, ry: 5, fill: "#5b3a29" }),
  ];
}

// mood: "sleeping" | "happy" | "ringing"   kind: "nuvi" | "gatinho" | "ursinho"
export function Mascot({ mood = "happy", size = 180, kind } = {}) {
  let which = (kind || getSettings().mascot).replace(/-noel$/, "");
  if (noelSeason()) return skinMascot(`${which}-noel`, mood, size);
  const svg = s("svg", {
    viewBox: "0 0 200 150",
    width: size,
    height: (size * 150) / 200,
    role: "img",
    "aria-label": "Mascote do Soninho",
  });
  svg.style.overflow = "visible";

  svg.append(s("ellipse", { cx: 100, cy: 142, rx: 55, ry: 6, fill: "#9ad0f5", opacity: ".35" }));
  const body = which === "gatinho" ? catBody() : which === "ursinho" ? bearBody() : cloudBody();
  body.forEach((part) => svg.append(part));

  const mouthDy = which === "ursinho" ? 8 : 0;

  if (mood === "sleeping") {
    svg.append(
      s("g", { stroke: "#5b6b8c", "stroke-width": 4, "stroke-linecap": "round", fill: "none" },
        s("path", { d: "M72 88 q8 8 16 0" }),
        s("path", { d: "M112 88 q8 8 16 0" }),
        s("path", { d: "M94 102 q6 5 12 0", transform: `translate(0 ${mouthDy})` }))
    );
  } else {
    const ringing = mood === "ringing";
    svg.append(
      s("g", {},
        s("circle", { cx: 80, cy: 88, r: 7, fill: "#3b4565" }),
        s("circle", { cx: 120, cy: 88, r: 7, fill: "#3b4565" }),
        s("circle", { cx: 82.5, cy: 85.5, r: 2.5, fill: "#fff" }),
        s("circle", { cx: 122.5, cy: 85.5, r: 2.5, fill: "#fff" }),
        s("path", {
          d: ringing ? "M90 99 q10 14 20 0 z" : "M92 100 q8 9 16 0",
          fill: ringing ? "#ff6aa2" : "none",
          stroke: "#3b4565",
          "stroke-width": 3.5,
          "stroke-linecap": "round",
          transform: `translate(0 ${mouthDy})`,
        }))
    );
  }

  svg.append(
    s("ellipse", { cx: 66, cy: 100, rx: 9, ry: 6, fill: "#ff8fb8", opacity: ".55" }),
    s("ellipse", { cx: 134, cy: 100, rx: 9, ry: 6, fill: "#ff8fb8", opacity: ".55" })
  );

  if (mood === "sleeping") {
    const z1 = s("text", { x: 150, y: 40, "font-size": 18 });
    z1.textContent = "z";
    const z2 = s("text", { x: 164, y: 26, "font-size": 24 });
    z2.textContent = "Z";
    anim(z1, "twinkle");
    anim(z2, "twinkle");
    svg.append(s("g", { fill: "#9ad0f5", "font-weight": 900, "font-family": "Nunito, sans-serif" }, z1, z2));
  }

  return anim(svg, mood === "ringing" ? "wiggle" : "float");
}
