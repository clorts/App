// Animação de entrada: nuvem dormindo que flutua, estrelinhas piscando e o nome do app.
import { h } from "./ui.js";

export function showSplash(ms = 2200) {
  const svg = `<svg viewBox="0 0 200 150" width="190" height="143" xmlns="http://www.w3.org/2000/svg">
    <g fill="#fff"><circle cx="60" cy="85" r="30"/><circle cx="100" cy="62" r="40"/><circle cx="142" cy="82" r="32"/><rect x="34" y="82" width="132" height="42" rx="21"/></g>
    <g fill="none" stroke="#7a4a63" stroke-width="4" stroke-linecap="round"><path d="M72 88q8 7 16 0"/><path d="M112 88q8 7 16 0"/><path d="M95 104q5 5 10 0"/></g>
    <ellipse cx="62" cy="104" rx="9" ry="5" fill="#ffb3cf"/><ellipse cx="138" cy="104" rx="9" ry="5" fill="#ffb3cf"/></svg>`;
  const cloud = h("div", { style: { lineHeight: "0" } });
  cloud.innerHTML = svg;
  const stars = [["18%", "22%", 0], ["80%", "18%", 400], ["72%", "70%", 800], ["25%", "64%", 1200]].map(([x, y, d]) => {
    const s = h("span", { style: { position: "absolute", left: x, top: y, fontSize: "22px", opacity: "0" } }, "✨");
    s.animate?.([{ opacity: 0 }, { opacity: 1 }, { opacity: 0 }], { duration: 1600, delay: d, iterations: Infinity });
    return s;
  });
  const title = h("div", { style: { marginTop: "12px", fontSize: "40px", fontWeight: "900", color: "#fff", letterSpacing: "-0.02em" } }, "Soninho");
  const sub = h("div", { style: { marginTop: "4px", fontSize: "16px", fontWeight: "800", color: "#ffffffcc" } }, "bom dia, dorminhoco ☁️");
  const box = h(
    "div",
    {
      style: {
        position: "fixed", inset: "0", zIndex: "9999", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        background: "linear-gradient(160deg,#ff8fb8,#ffc7de 60%,#bfe3ff)", fontFamily: "Nunito, ui-rounded, system-ui, sans-serif",
      },
    },
    ...stars, cloud, title, sub
  );
  cloud.animate?.([{ transform: "translateY(0)" }, { transform: "translateY(-14px)" }, { transform: "translateY(0)" }], { duration: 1800, iterations: Infinity, easing: "ease-in-out" });
  title.animate?.([{ opacity: 0, transform: "scale(.7)" }, { opacity: 1, transform: "scale(1)" }], { duration: 600, easing: "ease-out", fill: "both" });
  document.body.append(box);
  setTimeout(() => {
    const out = box.animate?.([{ opacity: 1 }, { opacity: 0 }], { duration: 400, fill: "forwards" });
    if (out) out.onfinish = () => box.remove();
    else box.remove();
  }, ms);
}
