// Ferramentas de interface: criar elementos, cores (com tema claro/escuro) e animações — tudo em JavaScript.
const LIGHT = {
  candy50: "#fff5f9",
  candy100: "#ffe4ef",
  candy200: "#ffc7de",
  candy400: "#ff8fb8",
  candy500: "#ff6aa2",
  candy600: "#e84d8a",
  skySoft: "#dff1ff",
  skyDeep: "#9ad0f5",
  slate700: "#334155",
  slate600: "#475569",
  slate500: "#64748b",
  slate400: "#94a3b8",
  slate300: "#cbd5e1",
  slate100: "#f1f5f9",
  white: "#ffffff",
  glass: "rgba(255,255,255,.7)",
  glass6: "rgba(255,255,255,.6)",
  glass8: "rgba(255,255,255,.8)",
};

const DARK = {
  candy50: "#33283a",
  candy100: "#3a2a42",
  candy200: "#5a3a58",
  candy400: "#ff8fb8",
  candy500: "#ff6aa2",
  candy600: "#ff9ec1",
  skySoft: "#1f3148",
  skyDeep: "#4a7aa6",
  slate700: "#f1f5f9",
  slate600: "#e2e8f0",
  slate500: "#cbd5e1",
  slate400: "#94a3b8",
  slate300: "#64748b",
  slate100: "#3f3a52",
  white: "#2a2234",
  glass: "rgba(42,34,52,.75)",
  glass6: "rgba(42,34,52,.6)",
  glass8: "rgba(42,34,52,.85)",
};

// As cores viram variáveis, então trocar o tema muda tudo na hora.
export const C = {
  ...Object.fromEntries(Object.keys(LIGHT).map((k) => [k, `var(--s-${k})`])),
  onPink: "#ffffff",
};

export function applyTheme(name) {
  const theme = name === "escuro" ? DARK : LIGHT;
  const root = document.documentElement;
  for (const [key, value] of Object.entries(theme)) root.style.setProperty(`--s-${key}`, value);
  root.style.colorScheme = name === "escuro" ? "dark" : "light";
}

export const FONT = "Nunito, ui-rounded, system-ui, sans-serif";

export function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(props ?? {})) {
    if (key === "style") Object.assign(el.style, value);
    else if (key.startsWith("on")) el.addEventListener(key.slice(2).toLowerCase(), value);
    else if (key === "value") el.value = value;
    else if (value === true) el.setAttribute(key, "");
    else if (value !== false && value != null) el.setAttribute(key, value);
  }
  for (const child of children.flat()) {
    if (child == null || child === false) continue;
    el.append(child.nodeType ? child : document.createTextNode(String(child)));
  }
  return el;
}

const KEYFRAMES = {
  float: [{ transform: "translateY(0)" }, { transform: "translateY(-10px)" }, { transform: "translateY(0)" }],
  wiggle: [{ transform: "rotate(-4deg)" }, { transform: "rotate(4deg)" }, { transform: "rotate(-4deg)" }],
  pop: [{ transform: "scale(.6)", opacity: 0 }, { transform: "scale(1)", opacity: 1 }],
  twinkle: [{ opacity: 0.4 }, { opacity: 1 }, { opacity: 0.4 }],
};
const TIMING = {
  float: { duration: 3000, iterations: Infinity, easing: "ease-in-out" },
  wiggle: { duration: 400, iterations: Infinity, easing: "ease-in-out" },
  pop: { duration: 250, easing: "ease-out" },
  twinkle: { duration: 2000, iterations: Infinity, easing: "ease-in-out" },
};

export function anim(el, name) {
  if (el.animate) el.animate(KEYFRAMES[name], TIMING[name]);
  return el;
}

export const buttonBase = {
  border: "none",
  cursor: "pointer",
  fontFamily: "inherit",
  fontWeight: "900",
  fontSize: "16px",
};

export const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  padding: "12px",
  borderRadius: "16px",
  border: "none",
  outline: "none",
  background: C.candy50,
  fontFamily: "inherit",
  fontWeight: "700",
  fontSize: "16px",
  color: C.slate700,
  marginBottom: "12px",
};

export function paintChip(button, active) {
  button.style.background = active ? C.candy500 : C.candy100;
  button.style.color = active ? C.onPink : C.candy600;
}

// Botãozinho redondo de escolha (usado nos ajustes).
export function chip(label, active, onClick) {
  const button = h("button", { onClick, style: { ...buttonBase, fontSize: "14px", padding: "8px 14px", borderRadius: "999px" } }, label);
  paintChip(button, active);
  return button;
}

// Fundo escuro + cartão (usado no formulário, na conta e nos ajustes).
export function modal(title, body, onClose) {
  const card = h(
    "div",
    {
      onClick: (e) => e.stopPropagation(),
      style: {
        width: "100%",
        maxWidth: "448px",
        maxHeight: "88vh",
        overflowY: "auto",
        boxSizing: "border-box",
        background: C.white,
        borderRadius: "32px",
        padding: "24px",
        boxShadow: "0 25px 50px -12px rgba(0,0,0,.25)",
      },
    },
    h("h2", { style: { margin: "0 0 16px", textAlign: "center", fontSize: "24px", fontWeight: "900", color: C.candy600 } }, title),
    body
  );
  anim(card, "pop");
  return h(
    "div",
    {
      onClick: onClose,
      style: {
        position: "fixed",
        inset: "0",
        zIndex: "40",
        display: "flex",
        alignItems: window.innerWidth >= 640 ? "center" : "flex-end",
        justifyContent: "center",
        padding: "12px",
        background: "rgba(15,23,42,.35)",
      },
    },
    card
  );
}
