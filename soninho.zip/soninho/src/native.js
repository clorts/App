// Despertador nativo do Android (só no app/APK). No navegador, nada aqui faz efeito.
import * as settings from "./settings.js";
import { hasCustom } from "./customSound.js";
import { NATAL_MSG, isDate25, isNatalDay, natalWindow } from "./natal.js";
import { TONES, nativeTone, toneFor } from "./tones.js";

const ONCE_KEY = "soninho:once";
const BED_ID = 2;

let SA = null; // despertador do Soninho (código Java)
let LN = null; // notificações locais (permissão + lembrete de dormir)

const ready = (async () => {
  try {
    if (!window.Capacitor) return;
    const core = await import("./vendor/capacitor-core.js");
    if (!core.Capacitor.isNativePlatform()) return;
    SA = core.registerPlugin("SoninhoAlarm");
    LN = core.registerPlugin("LocalNotifications");
  } catch (err) {
    console.warn("Alarmes nativos indisponíveis:", err);
  }
})();

export const isNative = () => SA !== null;

const readOnce = () => {
  try {
    return JSON.parse(localStorage.getItem(ONCE_KEY) || "{}");
  } catch {
    return {};
  }
};
const saveOnce = (map) => {
  try {
    localStorage.setItem(ONCE_KEY, JSON.stringify(map));
  } catch {
    /* ignora */
  }
};

function nextOccurrence(time) {
  const [hh, mm] = time.split(":").map(Number);
  const d = new Date();
  d.setHours(hh, mm, 0, 0);
  if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
  return d.getTime();
}

export async function init() {
  await ready;
  if (!LN) return;
  try {
    const perm = await LN.checkPermissions();
    if (perm.display !== "granted") await LN.requestPermissions();
  } catch (err) {
    console.warn("Erro ao pedir permissão de notificações:", err);
  }
}

// Alarmes de uma vez só que já tocaram (app fechado) são desligados aqui.
export async function expireOnce(getAlarms, disable) {
  await ready;
  if (!SA) return;
  const once = readOnce();
  for (const a of getAlarms()) {
    if (a.enabled && a.date && new Date(`${a.date}T${a.time}:00`).getTime() < Date.now() - 60_000) disable(a.id);
    if (a.enabled && a.days.length === 0 && once[a.id] && once[a.id] < Date.now() - 60_000) disable(a.id);
  }
}

// Deixa os alarmes do celular iguais aos do app (chame sempre que a lista, os toques ou os ajustes mudarem).
export async function syncNative(alarms) {
  await ready;
  if (!SA) return;
  const soft = settings.get().soft;
  const prev = readOnce();
  const once = {};
  const list = alarms.map((a) => {
    let enabled = a.enabled;
    const at = a.date ? new Date(`${a.date}T${a.time}:00`).getTime() : null;
    if (a.date) {
      if (at < Date.now() - 60_000) enabled = false; // dia já passou
    } else if (a.days.length === 0) {
      const stale = prev[a.id] && prev[a.id] < Date.now() - 60_000;
      if (stale) enabled = false; // já tocou; espera o app desligar
      else if (a.enabled) once[a.id] = prev[a.id] && prev[a.id] >= Date.now() ? prev[a.id] : nextOccurrence(a.time);
    }
    const natalTone = natalWindow() && hasCustom() ? TONES.find((t) => t.custom) : null; // "Ho ho ho!" gravado
    const label = isNatalDay() || isDate25(a.date) ? NATAL_MSG : a.label;
    return { id: a.id, label, time: a.time, days: a.days, enabled, tone: nativeTone(natalTone || toneFor(a.id)), soft, ...(at ? { at } : {}) };
  });
  saveOnce(once);
  try {
    await SA.schedule({ alarms: list });
  } catch (err) {
    console.warn("Erro ao agendar alarmes:", err);
  }
}

export async function saveCustomSound(b64) {
  await ready;
  if (!SA) return;
  await SA.saveCustomSound({ data: b64 });
}

export async function deleteCustomSound() {
  await ready;
  if (!SA) return;
  try {
    await SA.deleteCustomSound();
  } catch {
    /* ignora */
  }
}

// Identificador do aparelho (hash do ANDROID_ID), que continua o mesmo depois de desinstalar e instalar de novo.
export async function getDeviceKey() {
  await ready;
  if (!SA) return null;
  try {
    return (await SA.getDeviceKey()).key || null;
  } catch {
    return null;
  }
}

export async function getRinging() {
  await ready;
  if (!SA) return null;
  try {
    return await SA.getRinging();
  } catch {
    return null;
  }
}

export async function stopRinging() {
  await ready;
  if (!SA) return;
  try {
    await SA.stop();
  } catch {
    /* ignora */
  }
}

export async function snooze(minutes, tone, soft) {
  await ready;
  if (!SA) return;
  try {
    await SA.snooze({ minutes, tone: nativeTone(tone), soft });
  } catch (err) {
    console.warn("Erro na soneca:", err);
  }
}

// Lembrete diário de hora de dormir.
export async function setBedtime(on, time) {
  await ready;
  if (!LN) return;
  try {
    await LN.cancel({ notifications: [{ id: BED_ID }] });
    if (!on) return;
    const [hh, mm] = time.split(":").map(Number);
    await LN.schedule({
      notifications: [
        {
          id: BED_ID,
          title: "Hora de dormir 🌙",
          body: "A Nuvi já está com soninho. Vamos descansar? ☁️",
          schedule: { on: { hour: hh, minute: mm }, allowWhileIdle: true },
        },
      ],
    });
  } catch (err) {
    console.warn("Erro no lembrete de dormir:", err);
  }
}
