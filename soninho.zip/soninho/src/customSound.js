// Áudio próprio da pessoa (já convertido para WAV pelo app). Fica só neste aparelho.
const KEY = "soninho:custom-sound";
export const hasCustom = () => Boolean(localStorage.getItem(KEY));
export const getCustomB64 = () => localStorage.getItem(KEY);
export const setCustomB64 = (b64) => localStorage.setItem(KEY, b64); // pode lançar erro se não couber
export const clearCustom = () => localStorage.removeItem(KEY);
export const customUrl = () => (hasCustom() ? `data:audio/wav;base64,${localStorage.getItem(KEY)}` : null);
