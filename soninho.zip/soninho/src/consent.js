// Aviso de cookies/armazenamento. Sem aceitar, a fonte do Google não é carregada.
import { openLegal } from "./legal.js";
import { C, buttonBase, h } from "./ui.js";

const KEY = "soninho:consent";
const read = () => {
  try {
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
};

function loadFont() {
  if (document.getElementById("soninho-font")) return;
  document.head.append(h("link", { id: "soninho-font", rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Nunito:wght@600;800;900&display=swap" }));
}

function choose(value) {
  try {
    localStorage.setItem(KEY, value);
  } catch {
    /* ignora */
  }
  if (value === "all") loadFont();
}

export function showConsent() {
  const bar = h("div", { style: { position: "fixed", left: "12px", right: "12px", bottom: "12px", zIndex: "9000", maxWidth: "424px", margin: "0 auto", padding: "16px", borderRadius: "20px", background: C.white, color: C.slate600, boxShadow: "0 10px 30px rgba(0,0,0,.25)", fontSize: "13px", fontWeight: "700", lineHeight: "1.4" } });
  const pick = (v) => () => {
    choose(v);
    bar.remove();
  };
  bar.append(
    "🍪 Usamos armazenamento local essencial (alarmes, ajustes e login) e, se você deixar, a fonte do Google. Sem anúncios nem rastreio. ",
    h("a", { href: "#", onClick: (e) => { e.preventDefault(); openLegal("cookies"); }, style: { color: C.candy600 } }, "Saiba mais"),
    h("div", { style: { display: "flex", gap: "8px", marginTop: "12px" } },
      h("button", { onClick: pick("essential"), style: { ...buttonBase, flex: "1", padding: "10px", borderRadius: "14px", fontSize: "14px", background: C.slate100, color: C.slate500 } }, "Só o essencial"),
      h("button", { onClick: pick("all"), style: { ...buttonBase, flex: "1", padding: "10px", borderRadius: "14px", fontSize: "14px", background: C.candy500, color: C.onPink } }, "Aceitar")
    )
  );
  document.body.append(bar);
}

export function initConsent() {
  const v = read();
  if (v === "all") loadFont();
  else if (v !== "essential") showConsent();
}
