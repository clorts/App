// Contador de sono (fica salvo no aparelho): "Fui dormir" → desligar o alarme conta as horas.
const KEY = "soninho:sleep";
const listeners = new Set();

function read() {
  try {
    const d = JSON.parse(localStorage.getItem(KEY) || "{}");
    return { start: d.start || null, log: Array.isArray(d.log) ? d.log : [] };
  } catch {
    return { start: null, log: [] };
  }
}

let state = read();

function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* ignora */
  }
  listeners.forEach((fn) => fn(state));
}

export const getSleep = () => state;
export const hoursOf = (entry) => (entry.end - entry.start) / 36e5;

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function goToBed() {
  state = { ...state, start: Date.now() };
  save();
}

export function cancelBed() {
  state = { ...state, start: null };
  save();
}

export function wakeUp() {
  if (!state.start) return;
  const entry = { start: state.start, end: Date.now() };
  const hours = hoursOf(entry);
  const log = hours >= 0.5 && hours <= 20 ? [...state.log, entry].slice(-30) : state.log;
  state = { start: null, log };
  save();
}
