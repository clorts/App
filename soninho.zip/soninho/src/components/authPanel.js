import { C, buttonBase, h, inputStyle, modal } from "../ui.js";
import { supabase } from "../supabase.js";
import { clearLocal } from "../store.js";
import { forgetDevice } from "../device.js";
import { legalLinks, openLegal } from "../legal.js";

const friendly = (message) => {
  if (/invalid login/i.test(message)) return "E-mail ou senha incorretos 🙈";
  if (/already registered/i.test(message)) return "Esse e-mail já tem conta. Toque em Entrar 💌";
  if (/password/i.test(message)) return "A senha precisa ter pelo menos 6 caracteres 🔑";
  return message;
};

export function openAuth({ getSession }) {
  const close = () => overlay.remove();
  const body = h("div");
  const overlay = modal("Minha conta ☁️", body, close);
  document.body.append(overlay);

  const note = (text) => h("p", { style: { margin: "0 0 16px", textAlign: "center", fontWeight: "700", color: C.slate600 } }, text);

  if (!supabase) {
    body.append(note("Não consegui conectar na nuvem agora. Seus alarmes ficam salvos neste aparelho. 💾"));
    return;
  }

  const session = getSession();
  if (session) {
    body.append(
      note(`Conectado como ${session.user.email} ☁️`),
      h(
        "button",
        {
          onClick: async () => {
            await forgetDevice(); // ainda logado: quem sai de propósito não volta sozinho
            await supabase.auth.signOut();
            clearLocal();
            close();
          },
          style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", background: C.slate100, color: C.slate500 },
        },
        "Sair"
      ),
      h(
        "button",
        {
          onClick: async () => {
            if (!confirm("Apagar sua conta e todos os seus alarmes na nuvem? Não dá para desfazer.")) return;
            const { error } = await supabase.rpc("soninho_delete_me");
            if (error) return alert("Não consegui apagar agora. Tente de novo ou fale com o contato na Política de Privacidade.");
            await supabase.auth.signOut({ scope: "local" });
            clearLocal();
            close();
          },
          style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginTop: "10px", background: "transparent", color: C.candy600, fontSize: "14px" },
        },
        "Apagar minha conta e meus dados"
      ),
      legalLinks()
    );
    return;
  }

  const email = h("input", { type: "email", autocomplete: "email", placeholder: "seu e-mail", style: inputStyle });
  const password = h("input", { type: "password", autocomplete: "current-password", placeholder: "senha (mín. 6)", style: inputStyle });
  const msg = h("p", { style: { margin: "0 0 12px", textAlign: "center", fontSize: "14px", fontWeight: "700", color: C.candy600 } });
  const signUpBtn = h("button", { style: { ...buttonBase, flex: "1", padding: "12px", borderRadius: "16px", background: C.skySoft, color: C.slate600 } }, "Criar conta");
  const signInBtn = h("button", { style: { ...buttonBase, flex: "1", padding: "12px", borderRadius: "16px", background: C.candy500, color: C.onPink } }, "Entrar");

  const agree = h("input", { type: "checkbox", style: { marginRight: "8px" } });
  const agreeRow = h(
    "label",
    { style: { display: "block", margin: "0 0 12px", fontSize: "13px", fontWeight: "700", color: C.slate600 } },
    agree,
    "Li e aceito os ",
    h("a", { href: "#", onClick: (e) => { e.preventDefault(); openLegal("terms"); }, style: { color: C.candy600 } }, "Termos de Uso"),
    " e a ",
    h("a", { href: "#", onClick: (e) => { e.preventDefault(); openLegal("privacy"); }, style: { color: C.candy600 } }, "Política de Privacidade"),
    " (para criar conta)"
  );

  async function submit(mode) {
    msg.textContent = "";
    if (mode === "up" && !agree.checked) {
      msg.textContent = "Marque que aceita os Termos e a Política para criar a conta ✅";
      return;
    }
    if (!email.value.includes("@") || password.value.length < 6) {
      msg.textContent = "Digite um e-mail válido e uma senha com 6+ caracteres 🔑";
      return;
    }
    signUpBtn.disabled = signInBtn.disabled = true;
    const creds = { email: email.value.trim(), password: password.value };
    const { data, error } =
      mode === "in" ? await supabase.auth.signInWithPassword(creds) : await supabase.auth.signUp(creds);
    signUpBtn.disabled = signInBtn.disabled = false;
    if (error) msg.textContent = friendly(error.message);
    else if (mode === "up" && !data.session) msg.textContent = "Pronto! Confirme no seu e-mail 💌";
    else close();
  }

  signUpBtn.addEventListener("click", () => submit("up"));
  signInBtn.addEventListener("click", () => submit("in"));
  body.append(email, password, agreeRow, msg, h("div", { style: { display: "flex", gap: "12px" } }, signUpBtn, signInBtn));
}
