import { SNOOZE_MINUTES } from "./config.js";
import { alarmCard } from "./components/alarmCard.js";
import { openAlarmForm } from "./components/alarmForm.js";
import { openAuth } from "./components/authPanel.js";
import { Mascot } from "./components/mascot.js";
import { showRing } from "./components/ringScreen.js";
import * as native from "./native.js";
import { unlockAudio } from "./sound.js";
import * as store from "./store.js";
import { initSupabase, supabase } from "./supabase.js";
import { C, FONT, buttonBase, h } from "./ui.js";
import { greetingFor, nextAlarm, pad, toHHMM } from "./utils.js";

// ---------- estado ----------
let now = new Date();
let session = null;
let ringing = false;
let snoozeUntil = null;
let lastFired = "";
let mascotMood = null;

// ---------- página ----------
Object.assign(document.body.style, {
  margin: "0",
  minHeight: "100vh",
  fontFamily: FONT,
  color: C.slate700,
  background: `linear-gradient(to bottom, ${C.candy100}, ${C.skySoft}) fixed`,
  WebkitFontSmoothing: "antialiased",
});

const accountBtn = h("button", {
  onClick: () => openAuth({ getSession: () => session }),
  style: { ...buttonBase, padding: "8px 16px", borderRadius: "999px", background: C.white, color: C.slate500, fontSize: "14px", boxShadow: "0 1px 3px rgba(0,0,0,.15)" },
});

const mascotSlot = h("div");
const hhmmEl = h("span");
const secsEl = h("span", { style: { fontSize: "24px", color: C.candy400 } });
const greetEl = h("p", { style: { margin: "0", fontWeight: "800", color: C.slate500 } });
const nextEl = h("p", {
  style: { margin: "4px 0 0", padding: "4px 16px", borderRadius: "999px", background: "rgba(255,255,255,.7)", fontSize: "14px", fontWeight: "700", color: C.candy600 },
});
const listEl = h("main", { style: { marginTop: "24px", display: "flex", flexDirection: "column", gap: "12px" } });

const addBtn = h(
  "button",
  {
    "aria-label": "Novo alarme",
    onClick: () => openAlarmForm({ onSave: (draft) => store.addAlarm(draft) }),
    style: {
      ...buttonBase,
      position: "fixed",
      bottom: "24px",
      left: "50%",
      transform: "translateX(-50%)",
      width: "64px",
      height: "64px",
      borderRadius: "999px",
      background: C.candy500,
      color: C.white,
      fontSize: "36px",
      boxShadow: "0 20px 25px -5px rgba(255,143,184,.5)",
    },
  },
  "+"
);

const app = h(
  "div",
  { onPointerDown: unlockAudio, style: { boxSizing: "border-box", maxWidth: "448px", minHeight: "100vh", margin: "0 auto", padding: "24px 16px 112px" } },
  h(
    "header",
    { style: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" } },
    h("h1", { style: { margin: "0", fontSize: "24px", fontWeight: "900", color: C.candy600 } }, "Soninho ☁️"),
    accountBtn
  ),
  h(
    "section",
    { style: { display: "flex", flexDirection: "column", alignItems: "center" } },
    mascotSlot,
    h("div", { style: { fontSize: "60px", fontWeight: "900", letterSpacing: "-0.025em", color: C.slate700 } }, hhmmEl, secsEl),
    greetEl,
    nextEl
  ),
  listEl,
  addBtn
);
document.body.append(app);

// ---------- desenhar ----------
function renderClock() {
  hhmmEl.textContent = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
  secsEl.textContent = `:${pad(now.getSeconds())}`;
  greetEl.textContent = greetingFor(now.getHours());
}

function renderHero() {
  const next = nextAlarm(store.getAlarms(), now);
  const mood = next ? "sleeping" : "happy";
  if (mood !== mascotMood) {
    mascotMood = mood;
    mascotSlot.replaceChildren(Mascot({ mood }));
  }
  nextEl.textContent = next ? `Próximo despertar: ${next.time} • ${next.label}` : "Nenhum alarme ligado";
}

function renderList() {
  const alarms = store.getAlarms();
  listEl.replaceChildren();
  if (alarms.length === 0) {
    listEl.append(h("p", { style: { margin: "0", padding: "32px 0", textAlign: "center", fontWeight: "700", color: C.slate400 } }, "Nenhum alarme ainda. Toque no + 🌷"));
    return;
  }
  for (const a of alarms) {
    listEl.append(
      alarmCard(a, {
        onToggle: () => store.patchAlarm(a.id, { enabled: !a.enabled }),
        onDelete: () => store.removeAlarm(a.id),
      })
    );
  }
}

function renderAccount() {
  accountBtn.textContent = session ? "☁️ Minha conta" : "Entrar";
}

store.subscribe(() => {
  renderList();
  renderHero();
  native.syncNative(store.getAlarms());
});

// ---------- alarmes tocando ----------
function ring({ label, time, alarmId }) {
  ringing = true;
  showRing({
    label,
    time,
    onSnooze: () => {
      snoozeUntil = Date.now() + SNOOZE_MINUTES * 60_000;
      native.scheduleSnooze(SNOOZE_MINUTES * 60_000);
      native.clearDelivered();
      ringing = false;
    },
    onDismiss: () => {
      const a = alarmId && store.getAlarms().find((x) => x.id === alarmId);
      if (a && a.days.length === 0) store.patchAlarm(a.id, { enabled: false }); // alarme de uma vez só
      native.cancelSnooze();
      native.clearDelivered();
      ringing = false;
    },
  });
}

function checkAlarms() {
  if (ringing) return;
  const hhmm = toHHMM(now);
  const stamp = `${now.toDateString()} ${hhmm}`;

  if (snoozeUntil && now.getTime() >= snoozeUntil) {
    snoozeUntil = null;
    ring({ label: "Soneca acabou! ⏰", time: hhmm });
    return;
  }

  if (lastFired === stamp || now.getSeconds() > 30) return;
  const due = store.getAlarms().find((a) => a.enabled && a.time === hhmm && (a.days.length === 0 || a.days.includes(now.getDay())));
  if (due) {
    lastFired = stamp;
    ring({ label: due.label, time: due.time, alarmId: due.id });
  }
}

function tick() {
  now = new Date();
  renderClock();
  renderHero();
  checkAlarms();
}

// ---------- começar ----------
renderAccount();
renderClock();
renderList();
renderHero();
setInterval(tick, 1000);

(async function start() {
  await initSupabase();
  if (!supabase) return;
  const { data } = await supabase.auth.getSession();
  session = data.session;
  renderAccount();
  store.setUser(session ? session.user.id : null);
  supabase.auth.onAuthStateChange((_event, s) => {
    session = s;
    renderAccount();
    store.setUser(s ? s.user.id : null);
  });
})();

// ---------- alarmes nativos (APK) ----------
const disableAlarm = (id) => store.patchAlarm(id, { enabled: false });

(async function startNative() {
  await native.init();
  native.onTap((extra) => {
    if (ringing) return;
    snoozeUntil = null;
    lastFired = `${now.toDateString()} ${toHHMM(now)}`;
    ring({ label: extra.label || "Soneca acabou! ⏰", time: extra.time || toHHMM(new Date()), alarmId: extra.alarmId });
  });
  await native.expireOnce(store.getAlarms, disableAlarm);
  native.syncNative(store.getAlarms());
})();

document.addEventListener("visibilitychange", () => {
  if (!document.hidden) native.expireOnce(store.getAlarms, disableAlarm);
});
