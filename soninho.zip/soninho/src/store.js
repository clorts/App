import { TABLE } from "./config.js";
import { supabase } from "./supabase.js";

const KEY = "soninho:alarms";
const PENDING = "soninho:pending"; // alarmes feitos sem conta, ainda não enviados para a nuvem
const COLS = "id,label,time,days,enabled,date,tone";
const BASIC = "id,label,time,days,enabled";
const listeners = new Set();

const sortByTime = (list) => [...list].sort((a, b) => (a.date || "").localeCompare(b.date || "") || a.time.localeCompare(b.time));
const parse = (key, fallback) => {
  try {
    return JSON.parse(localStorage.getItem(key) || fallback);
  } catch {
    return JSON.parse(fallback);
  }
};
const save = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* armazenamento cheio ou bloqueado */
  }
};
// Coluna nova (date/tone) ainda não criada no Supabase: tenta de novo sem elas.
const missingCol = (e) => Boolean(e && /column|schema cache|does not exist/i.test(e.message || ""));
const strip = ({ date, tone, ...rest }) => rest;
const clean = (a) => ({ ...a, days: a.days || [], date: a.date || undefined, tone: a.tone || undefined });

let alarms = sortByTime(parse(KEY, "[]"));
let userId = null;

function emit() {
  save(KEY, alarms);
  if (userId) save(`${KEY}:${userId}`, alarms); // cópia da conta: o alarme não se perde nem sem internet
  listeners.forEach((fn) => fn(alarms));
}

const remote = () => Boolean(supabase && userId);
const pending = () => new Set(parse(PENDING, "[]"));
const setPending = (set) => save(PENDING, [...set]);

export const getAlarms = () => alarms;

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

async function insertRows(rows) {
  let { error } = await supabase.from(TABLE).insert(rows);
  if (missingCol(error)) ({ error } = await supabase.from(TABLE).insert(rows.map(strip)));
  return error;
}

// Chamado quando alguém entra (id) ou sai (null) da conta.
export async function setUser(id) {
  userId = id;
  if (!supabase || !id) return;
  let { data, error } = await supabase.from(TABLE).select(COLS);
  if (missingCol(error)) ({ data, error } = await supabase.from(TABLE).select(BASIC));
  if (error || !data) {
    console.warn("Erro ao buscar alarmes:", error);
    const cached = parse(`${KEY}:${id}`, "null");
    if (cached && alarms.length === 0) {
      alarms = sortByTime(cached);
      emit();
    }
    return;
  }
  // Alarmes feitos antes de entrar na conta sobem para a nuvem (os da conta nunca são apagados daqui).
  const ids = new Set(data.map((a) => a.id));
  const wait = pending();
  const local = alarms.filter((a) => !ids.has(a.id) && (wait.has(a.id) || data.length === 0));
  if (local.length > 0) {
    const err = await insertRows(local.map((a) => ({ ...a, user_id: id })));
    if (err) console.warn("Erro ao enviar alarmes:", err);
    else setPending(new Set([...wait].filter((x) => !local.some((a) => a.id === x))));
  }
  // O toque de cada alarme acompanha a conta em qualquer aparelho.
  const tones = parse("soninho:tones", "{}");
  for (const a of data) if (a.tone && !tones[a.id]) tones[a.id] = a.tone;
  save("soninho:tones", tones);
  alarms = sortByTime([...data.map(clean), ...local]);
  emit();
}

// Ao sair da conta, limpa o aparelho para não misturar com outra pessoa (os alarmes continuam salvos na conta).
export function clearLocal() {
  alarms = [];
  emit();
}

export async function addAlarm(draft) {
  const alarm = { id: crypto.randomUUID(), enabled: true, ...draft };
  alarms = sortByTime([...alarms, alarm]);
  emit();
  if (remote()) {
    const error = await insertRows([{ ...alarm, user_id: userId }]);
    if (error) {
      console.warn("Erro ao salvar:", error);
      setPending(new Set([...pending(), alarm.id])); // tenta de novo no próximo login
    }
  } else {
    setPending(new Set([...pending(), alarm.id]));
  }
}

export async function patchAlarm(id, changes) {
  alarms = sortByTime(alarms.map((a) => (a.id === id ? { ...a, ...changes } : a)));
  emit();
  if (remote()) {
    let { error } = await supabase.from(TABLE).update(changes).eq("id", id);
    if (missingCol(error)) ({ error } = await supabase.from(TABLE).update(strip(changes)).eq("id", id));
    if (error) console.warn("Erro ao atualizar:", error);
  }
}

export async function removeAlarm(id) {
  alarms = alarms.filter((a) => a.id !== id);
  emit();
  if (remote()) {
    const { error } = await supabase.from(TABLE).delete().eq("id", id);
    if (error) console.warn("Erro ao apagar:", error);
  }
}
