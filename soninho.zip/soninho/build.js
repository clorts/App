// Gera a pasta "dist" (a página que o navegador abre) a partir do JavaScript em src/.
// Não precisa de npm install: só Node.js.
import { cpSync, existsSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const dist = join(root, "dist");

rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });
cpSync(join(root, "src"), join(dist, "src"), { recursive: true });

// No APK, o JavaScript do Capacitor vem do node_modules (no Netlify não existe, e tudo bem).
const core = join(root, "node_modules", "@capacitor", "core", "dist", "index.js");
if (existsSync(core)) {
  mkdirSync(join(dist, "src", "vendor"), { recursive: true });
  cpSync(core, join(dist, "src", "vendor", "capacitor-core.js"));
}

const page = [
  "<!doctype html>",
  '<html lang="pt-BR">',
  "<head>",
  '<meta charset="UTF-8" />',
  '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />',
  '<meta name="theme-color" content="#ffc7de" />',
  "<title>Soninho ☁️ Despertador Fofo</title>",
  "</head>",
  "<body>",
  '<script type="module" src="/src/main.js"></script>',
  "</body>",
  "</html>",
  "",
].join("\n");

writeFileSync(join(dist, "index.html"), page);
console.log("Soninho pronto na pasta dist/ ☁️");
