// A chave "publishable" foi feita para ficar no app. NUNCA coloque a "secret" aqui.
export const SUPABASE_URL = "https://umvubiugozvaqmaweocw.supabase.co";
export const SUPABASE_KEY = "sb_publishable_92OWhkb6niSG8Yi9Y3HZLA_mlZJVzbP";
export const TABLE = "soninho_alarms";

export const SNOOZE_MINUTES = 5;
export const STARS_NEEDED = 5;
export const DAY_LABELS = ["D", "S", "T", "Q", "Q", "S", "S"];
export const SHAKES_NEEDED = 12;

// TROQUE pelo seu e-mail de contato (aparece na Política de Privacidade e nos Termos).
export const CONTACT_EMAIL = "ferreiradosreis130@gmail.com";
export const LEGAL_UPDATED = "27/10/2026";

// Link do seu site (Netlify). Usado no botão "Compartilhar" e no cartão de Natal. Ex.: "https://soninho.netlify.app"
// Se ficar vazio, o site usa o endereço em que está aberto (no APK precisa preencher aqui).
export const SHARE_URL = "https://reelogio.netlify.app";
