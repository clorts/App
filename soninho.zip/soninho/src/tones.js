import { hasCustom } from "./customSound.js";
import * as settings from "./settings.js";

// Os toques são definidos aqui; o celular recebe as mesmas notas e toca em loop.
export const TONES = [
  { id: "melodia", name: "Melodia fofa", wave: "triangle", step: 280, notes: [523.25, 659.25, 783.99, 659.25, 880.0, 783.99, 659.25, 587.33] },
  { id: "sininho", name: "Sininho", wave: "sine", step: 220, notes: [1046.5, 1318.5, 1568.0, 1318.5, 1046.5, 1568.0, 2093.0, 1568.0] },
  { id: "harpa", name: "Harpa suave", wave: "sine", step: 260, notes: [392.0, 493.88, 587.33, 783.99, 987.77, 783.99, 587.33, 493.88] },
  { id: "alegre", name: "Alegre", wave: "square", step: 180, notes: [659.25, 987.77, 659.25, 987.77, 1174.66, 987.77, 783.99, 0] },
  { id: "sistema", name: "Toque do celular", system: true, notes: [] },
  { id: "custom", name: "Meu áudio", custom: true, notes: [] },
];

const KEY = "soninho:tones";

const readMap = () => {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "{}");
  } catch {
    return {};
  }
};

export const toneById = (id) => TONES.find((t) => t.id === id && (!t.custom || hasCustom())) || TONES[0];

export const getToneId = (alarmId) => readMap()[alarmId] || settings.get().tone;

export function setToneId(alarmId, toneId) {
  const map = readMap();
  map[alarmId] = toneId;
  try {
    localStorage.setItem(KEY, JSON.stringify(map));
  } catch {
    /* ignora */
  }
}

export const toneFor = (alarmId) => toneById(getToneId(alarmId));

// Formato enviado ao Android.
export const nativeTone = (t) => ({ wave: t.wave || "triangle", step: t.step || 280, notes: t.notes || [], system: Boolean(t.system), custom: Boolean(t.custom) });
