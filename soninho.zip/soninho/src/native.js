// Alarmes nativos (só no app instalado/APK). No navegador, tudo aqui não faz nada.
const CHANNEL = "alarmes";
const SNOOZE_ID = 1;
const ONCE_KEY = "soninho:once";

let LN = null;

const ready = (async () => {
  try {
    if (!window.Capacitor) return;
    const core = await import("./vendor/capacitor-core.js");
    if (core.Capacitor.isNativePlatform()) LN = core.registerPlugin("LocalNotifications");
  } catch (err) {
    console.warn("Alarmes nativos indisponíveis:", err);
  }
})();

// Número inteiro único para cada alarme + dia da semana (k = 0..6, 7 = alarme de uma vez só).
function idFor(alarmId, k) {
  let n = 0;
  for (const ch of alarmId) n = (n * 31 + ch.charCodeAt(0)) % 268435000;
  return n * 8 + k + 10;
}

function nextOccurrence(hh, mm) {
  const d = new Date();
  d.setHours(hh, mm, 0, 0);
  if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
  return d;
}

const readOnce = () => {
  try {
    return JSON.parse(localStorage.getItem(ONCE_KEY) || "{}");
  } catch {
    return {};
  }
};
const saveOnce = (map) => {
  try {
    localStorage.setItem(ONCE_KEY, JSON.stringify(map));
  } catch {
    /* ignora */
  }
};

export async function init() {
  await ready;
  if (!LN) return;
  try {
    const perm = await LN.checkPermissions();
    if (perm.display !== "granted") await LN.requestPermissions();
    await LN.createChannel({
      id: CHANNEL,
      name: "Alarmes",
      description: "Despertar do Soninho",
      importance: 5,
      visibility: 1,
      vibration: true,
      lights: true,
    });
  } catch (err) {
    console.warn("Erro ao preparar notificações:", err);
  }
}

// Alarmes de uma vez só que já passaram (tocaram com o app fechado) são desligados.
export async function expireOnce(getAlarms, disable) {
  await ready;
  if (!LN) return;
  const once = readOnce();
  for (const a of getAlarms()) {
    if (a.enabled && a.days.length === 0 && once[a.id] && once[a.id] < Date.now() - 60_000) disable(a.id);
  }
}

async function doSync(alarms) {
  const pending = await LN.getPending();
  const ours = pending.notifications.filter((n) => n.id !== SNOOZE_ID);
  if (ours.length > 0) await LN.cancel({ notifications: ours.map((n) => ({ id: n.id })) });

  const notifications = [];
  const once = {};
  for (const a of alarms.filter((x) => x.enabled)) {
    const [hh, mm] = a.time.split(":").map(Number);
    const base = {
      title: `${a.label} ⏰`,
      body: `São ${a.time} — hora de acordar! ☁️`,
      channelId: CHANNEL,
      extra: { alarmId: a.id, label: a.label, time: a.time },
    };
    if (a.days.length === 0) {
      const at = nextOccurrence(hh, mm);
      once[a.id] = at.getTime();
      notifications.push({ ...base, id: idFor(a.id, 7), schedule: { at, allowWhileIdle: true } });
    } else {
      for (const d of a.days) {
        notifications.push({
          ...base,
          id: idFor(a.id, d),
          schedule: { on: { weekday: d + 1, hour: hh, minute: mm }, allowWhileIdle: true },
        });
      }
    }
  }
  saveOnce(once);
  if (notifications.length > 0) await LN.schedule({ notifications });
}

let latest = null;
let running = false;

// Deixa os alarmes do celular iguais aos do app (chame sempre que a lista mudar).
export async function syncNative(alarms) {
  await ready;
  if (!LN) return;
  latest = alarms;
  if (running) return;
  running = true;
  try {
    while (latest) {
      const current = latest;
      latest = null;
      await doSync(current);
    }
  } catch (err) {
    console.warn("Erro ao agendar alarmes:", err);
  }
  running = false;
}

export async function scheduleSnooze(ms) {
  await ready;
  if (!LN) return;
  try {
    await LN.schedule({
      notifications: [
        {
          id: SNOOZE_ID,
          title: "Soneca acabou! ⏰",
          body: "Hora de acordar de verdade ☁️",
          channelId: CHANNEL,
          extra: { snooze: true },
          schedule: { at: new Date(Date.now() + ms), allowWhileIdle: true },
        },
      ],
    });
  } catch (err) {
    console.warn("Erro na soneca:", err);
  }
}

export async function cancelSnooze() {
  await ready;
  if (!LN) return;
  try {
    await LN.cancel({ notifications: [{ id: SNOOZE_ID }] });
  } catch {
    /* ignora */
  }
}

export async function clearDelivered() {
  await ready;
  if (!LN) return;
  try {
    await LN.removeAllDeliveredNotifications();
  } catch {
    /* ignora */
  }
}

// Quando a pessoa toca na notificação, o app abre e chama cb com os dados do alarme.
export async function onTap(cb) {
  await ready;
  if (!LN) return;
  LN.addListener("localNotificationActionPerformed", (event) => cb((event.notification && event.notification.extra) || {}));
}
