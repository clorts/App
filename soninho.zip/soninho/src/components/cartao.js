import { SKINS } from "./mascot.js";
import { baseUrl, shareText } from "../share.js";
import { C, buttonBase, h, inputStyle, modal } from "../ui.js";

const skinUrl = (k) => new URL(`../assets/skins/${k}.png`, import.meta.url).href;
const encode = (d) => btoa(unescape(encodeURIComponent(JSON.stringify(d))));
const decode = (s) => JSON.parse(decodeURIComponent(escape(atob(s))));

// O cartão animado (usado na prévia e na página que abre pelo link do WhatsApp).
function cardView({ to, from, skin }) {
  const card = h("div", { style: { position: "relative", overflow: "hidden", borderRadius: "28px", padding: "28px 16px 24px", textAlign: "center", color: "#fff", background: "linear-gradient(160deg,#c0283a,#7a1426 55%,#1f6b45)", boxShadow: "0 12px 30px rgba(0,0,0,.3)" } });
  for (let i = 0; i < 18; i++) {
    const f = h("span", { style: { position: "absolute", top: "-30px", left: `${Math.random() * 100}%`, fontSize: `${10 + Math.random() * 12}px` } }, i % 6 === 0 ? "✦" : "•");
    f.animate([{ transform: "translateY(0)" }, { transform: "translateY(520px)" }], { duration: 4000 + Math.random() * 5000, iterations: Infinity, delay: -Math.random() * 8000 });
    card.append(f);
  }
  const img = h("img", { src: skinUrl(skin), alt: "", style: { position: "relative", width: "170px", maxHeight: "170px", objectFit: "contain" } });
  img.animate([{ transform: "translateY(0) rotate(-3deg)" }, { transform: "translateY(-14px) rotate(3deg)" }, { transform: "translateY(0) rotate(-3deg)" }], { duration: 1800, iterations: Infinity, easing: "ease-in-out" });
  const title = h("div", { style: { position: "relative", fontSize: "30px", fontWeight: "900", marginTop: "8px" } }, "Feliz Natal!");
  title.animate([{ transform: "scale(1)" }, { transform: "scale(1.07)" }, { transform: "scale(1)" }], { duration: 1500, iterations: Infinity });
  card.append(
    img,
    title,
    h("div", { style: { position: "relative", fontSize: "18px", fontWeight: "800", marginTop: "10px" } }, to ? `Para ${to}` : "Para você"),
    h("div", { style: { position: "relative", fontSize: "15px", fontWeight: "700", marginTop: "8px", opacity: ".95" } }, "Que a sua manhã seja cheia de carinho, paz e presentes!"),
    h("div", { style: { position: "relative", fontSize: "14px", fontWeight: "800", marginTop: "12px" } }, from ? `Com carinho, ${from}` : "Com carinho")
  );
  return card;
}

// Imagem do cartão (para mandar quando não há link do site).
async function cardPng({ to, from, skin }) {
  const c = document.createElement("canvas");
  c.width = 1080;
  c.height = 1350;
  const x = c.getContext("2d");
  const g = x.createLinearGradient(0, 0, 1080, 1350);
  g.addColorStop(0, "#c0283a");
  g.addColorStop(0.55, "#7a1426");
  g.addColorStop(1, "#1f6b45");
  x.fillStyle = g;
  x.fillRect(0, 0, 1080, 1350);
  x.font = "40px sans-serif";
  for (let i = 0; i < 40; i++) x.fillText(i % 6 === 0 ? "✦" : "•", Math.random() * 1040, Math.random() * 1300 + 40);
  const im = new Image();
  im.src = skinUrl(skin);
  await im.decode();
  const w = 560;
  x.drawImage(im, (1080 - w) / 2, 200, w, (im.height / im.width) * w);
  x.fillStyle = "#fff";
  x.textAlign = "center";
  x.font = "900 110px sans-serif";
  x.fillText("Feliz Natal!", 540, 960);
  x.font = "800 60px sans-serif";
  x.fillText(to ? `Para ${to}` : "Para você", 540, 1060);
  x.font = "700 44px sans-serif";
  x.fillText("Que a sua manhã seja cheia de carinho!", 540, 1140);
  x.fillText(from ? `Com carinho, ${from}` : "Com carinho", 540, 1220);
  return new Promise((r) => c.toBlob(r, "image/png"));
}

export function openCartao() {
  const data = { to: "", from: "", skin: SKINS[0] };
  const close = () => overlay.remove();
  const preview = h("div");
  const paint = () => preview.replaceChildren(cardView(data));
  const field = (ph, key) => h("input", { type: "text", maxlength: "24", placeholder: ph, onInput: (e) => { data[key] = e.target.value.trim(); paint(); }, style: { ...inputStyle, marginBottom: "8px" } });
  const picks = h("div", { style: { display: "flex", gap: "8px", justifyContent: "center", margin: "4px 0 12px" } });
  const paintPicks = () =>
    picks.replaceChildren(
      ...SKINS.map((k) =>
        h("button", { onClick: () => { data.skin = k; paint(); paintPicks(); }, style: { ...buttonBase, padding: "6px", borderRadius: "16px", background: data.skin === k ? C.candy500 : C.candy100 } }, h("img", { src: skinUrl(k), alt: k, style: { width: "56px", height: "48px", objectFit: "contain" } }))
      )
    );
  const sendLink = h("button", {
    onClick: () => {
      const url = baseUrl();
      const text = "🎄 Feliz Natal! Fiz um cartão animado para você:";
      if (!url) return shareImage();
      shareText(text, `${url}/#cartao=${encode(data)}`);
    },
    style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginTop: "12px", background: "#25d366", color: "#fff" },
  }, "📲 Enviar no WhatsApp");
  async function shareImage() {
    const blob = await cardPng(data);
    const file = new File([blob], "cartao-de-natal.png", { type: "image/png" });
    if (navigator.canShare && navigator.canShare({ files: [file] })) return void navigator.share({ files: [file], text: "🎄 Feliz Natal!" }).catch(() => {});
    const a = h("a", { href: URL.createObjectURL(blob), download: "cartao-de-natal.png" });
    a.click();
  }
  const imgBtn = h("button", { onClick: shareImage, style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginTop: "8px", background: C.candy100, color: C.candy600 } }, "🖼️ Enviar como imagem");
  const body = h("div", {}, field("Para quem? (ex: Vovó)", "to"), field("Seu nome", "from"), picks, preview, sendLink, imgBtn,
    h("button", { onClick: close, style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginTop: "8px", background: C.slate100, color: C.slate500 } }, "Fechar"));
  paintPicks();
  paint();
  const overlay = modal("Cartão de Natal 💌", body, close);
  document.body.append(overlay);
}

// Quem abre o link recebido vê o cartão animado em tela cheia.
export function showCartaoFromHash() {
  if (!location.hash.startsWith("#cartao=")) return;
  let data;
  try {
    data = decode(location.hash.slice(8));
    if (!SKINS.includes(data.skin)) data.skin = SKINS[0];
  } catch {
    return;
  }
  const root = h("div", { style: { position: "fixed", inset: "0", zIndex: "60", display: "flex", alignItems: "center", justifyContent: "center", padding: "16px", background: "rgba(15,23,42,.6)" } },
    h("div", { style: { width: "100%", maxWidth: "380px" } }, cardView({ to: String(data.to || "").slice(0, 24), from: String(data.from || "").slice(0, 24), skin: data.skin }),
      h("button", { onClick: () => { root.remove(); history.replaceState(null, "", location.pathname); }, style: { ...buttonBase, width: "100%", marginTop: "14px", padding: "12px", borderRadius: "16px", background: "#fff", color: "#b01e2e" } }, "Abrir o Soninho")));
  document.body.append(root);
}
