// Aviso de versão nova (só no APK; o site se atualiza sozinho).
import { APK_URL, APP_VERSION, SHARE_URL } from "./config.js";
import * as native from "./native.js";
import { C, buttonBase, h, modal } from "./ui.js";

const SKIP = "soninho:update-skip";
const newer = (a, b) => {
  const x = String(a).split(".").map(Number);
  const y = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  return false;
};

export async function checkUpdate() {
  if (!native.isNative() || !SHARE_URL) return;
  try {
    const skip = JSON.parse(localStorage.getItem(SKIP) || "{}");
    const res = await fetch(`${SHARE_URL.replace(/\/$/, "")}/version.json?t=${Date.now()}`, { cache: "no-store" });
    const { version } = await res.json();
    if (!newer(version, APP_VERSION)) return;
    if (skip.version === version && Date.now() - skip.at < 86_400_000) return; // "Agora não": pergunta de novo amanhã
    const close = () => overlay.remove();
    const body = h(
      "div",
      {},
      h("p", { style: { margin: "0 0 16px", textAlign: "center", fontWeight: "700", color: C.slate600 } }, "Tem novidades no Soninho! 🎄 Baixe e instale para continuar com tudo funcionando."),
      h("button", {
        onClick: () => window.open(APK_URL || `${SHARE_URL.replace(/\/$/, "")}/soninho.apk`, "_blank"),
        style: { ...buttonBase, width: "100%", padding: "14px", borderRadius: "16px", background: C.candy500, color: C.onPink },
      }, "⬇️ Baixar versão nova"),
      h("button", {
        onClick: () => {
          localStorage.setItem(SKIP, JSON.stringify({ version, at: Date.now() }));
          close();
        },
        style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginTop: "8px", background: C.slate100, color: C.slate500 },
      }, "Agora não")
    );
    const overlay = modal("Versão nova! 🎉", body, close);
    document.body.append(overlay);
  } catch {
    /* sem internet: tudo bem */
  }
}
