import { SNOOZE_MINUTES } from "./config.js";
import { alarmCard } from "./components/alarmCard.js";
import { openAlarmForm } from "./components/alarmForm.js";
import { openAuth } from "./components/authPanel.js";
import { Mascot } from "./components/mascot.js";
import { showRing } from "./components/ringScreen.js";
import { openSettings } from "./components/settingsPanel.js";
import { SleepCard } from "./components/sleepCard.js";
import * as native from "./native.js";
import * as settings from "./settings.js";
import * as sleep from "./sleep.js";
import { unlockAudio } from "./sound.js";
import * as store from "./store.js";
import { initSupabase, supabase } from "./supabase.js";
import { getToneId, setToneId, toneById, toneFor } from "./tones.js";
import { C, FONT, applyTheme, buttonBase, h } from "./ui.js";
import { greetingFor, nextAlarm, pad, toHHMM } from "./utils.js";

// ---------- estado ----------
let now = new Date();
let session = null;
let ringing = false;
let snoozeUntil = null;
let lastFired = "";
let mascotKey = null;
let ignoreNativeUntil = 0;
let polling = false;

// ---------- página ----------
applyTheme(settings.get().theme);
Object.assign(document.body.style, {
  margin: "0",
  minHeight: "100vh",
  fontFamily: FONT,
  color: C.slate700,
  background: `linear-gradient(to bottom, ${C.candy100}, ${C.skySoft}) fixed`,
  WebkitFontSmoothing: "antialiased",
});

const smallButton = {
  ...buttonBase,
  padding: "8px 16px",
  borderRadius: "999px",
  background: C.white,
  color: C.slate500,
  fontSize: "14px",
  boxShadow: "0 1px 3px rgba(0,0,0,.15)",
};

const accountBtn = h("button", { onClick: () => openAuth({ getSession: () => session }), style: smallButton });
const settingsBtn = h("button", { "aria-label": "Ajustes", onClick: openSettings, style: { ...smallButton, padding: "8px 12px" } }, "⚙️");

const mascotSlot = h("div");
const hhmmEl = h("span");
const secsEl = h("span", { style: { fontSize: "24px", color: C.candy400 } });
const greetEl = h("p", { style: { margin: "0", fontWeight: "800", color: C.slate500 } });
const nextEl = h("p", {
  style: { margin: "4px 0 0", padding: "4px 16px", borderRadius: "999px", background: C.glass, fontSize: "14px", fontWeight: "700", color: C.candy600 },
});
const listEl = h("main", { style: { marginTop: "24px", display: "flex", flexDirection: "column", gap: "12px" } });

const addBtn = h(
  "button",
  {
    "aria-label": "Novo alarme",
    onClick: () =>
      openAlarmForm({
        onSave: ({ tone, ...draft }) => {
          const id = crypto.randomUUID();
          setToneId(id, tone); // o toque fica no aparelho; o id é o mesmo do alarme
          store.addAlarm({ ...draft, id });
        },
      }),
    style: {
      ...buttonBase,
      position: "fixed",
      bottom: "24px",
      left: "50%",
      transform: "translateX(-50%)",
      width: "64px",
      height: "64px",
      borderRadius: "999px",
      background: C.candy500,
      color: C.onPink,
      fontSize: "36px",
      boxShadow: "0 20px 25px -5px rgba(255,143,184,.5)",
    },
  },
  "+"
);

const app = h(
  "div",
  { onPointerDown: unlockAudio, style: { boxSizing: "border-box", maxWidth: "448px", minHeight: "100vh", margin: "0 auto", padding: "24px 16px 112px" } },
  h(
    "header",
    { style: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" } },
    h("h1", { style: { margin: "0", fontSize: "24px", fontWeight: "900", color: C.candy600 } }, "Soninho ☁️"),
    h("div", { style: { display: "flex", gap: "8px" } }, settingsBtn, accountBtn)
  ),
  h(
    "section",
    { style: { display: "flex", flexDirection: "column", alignItems: "center" } },
    mascotSlot,
    h("div", { style: { fontSize: "60px", fontWeight: "900", letterSpacing: "-0.025em", color: C.slate700 } }, hhmmEl, secsEl),
    greetEl,
    nextEl
  ),
  listEl,
  SleepCard(),
  addBtn
);
document.body.append(app);

// ---------- desenhar ----------
function renderClock() {
  hhmmEl.textContent = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
  secsEl.textContent = `:${pad(now.getSeconds())}`;
  greetEl.textContent = greetingFor(now.getHours());
}

function renderHero() {
  const next = nextAlarm(store.getAlarms(), now);
  const mood = next ? "sleeping" : "happy";
  const key = `${mood}:${settings.get().mascot}`;
  if (key !== mascotKey) {
    mascotKey = key;
    mascotSlot.replaceChildren(Mascot({ mood }));
  }
  nextEl.textContent = next ? `Próximo despertar: ${next.time} • ${next.label}` : "Nenhum alarme ligado";
}

function renderList() {
  const alarms = store.getAlarms();
  listEl.replaceChildren();
  if (alarms.length === 0) {
    listEl.append(h("p", { style: { margin: "0", padding: "32px 0", textAlign: "center", fontWeight: "700", color: C.slate400 } }, "Nenhum alarme ainda. Toque no + 🌷"));
    return;
  }
  for (const a of alarms) {
    listEl.append(
      alarmCard(a, {
        toneId: toneById(getToneId(a.id)).id,
        onToggle: () => store.patchAlarm(a.id, { enabled: !a.enabled }),
        onDelete: () => store.removeAlarm(a.id),
        onTone: (id) => {
          setToneId(a.id, id);
          renderList();
          native.syncNative(store.getAlarms());
        },
      })
    );
  }
}

function renderAccount() {
  accountBtn.textContent = session ? "☁️ Minha conta" : "Entrar";
}

store.subscribe(() => {
  renderList();
  renderHero();
  native.syncNative(store.getAlarms());
});

settings.subscribe((s) => {
  applyTheme(s.theme);
  mascotKey = null;
  renderHero();
  renderList();
  native.syncNative(store.getAlarms());
  native.setBedtime(s.bedtimeOn, s.bedtime);
});

// ---------- alarmes tocando ----------
function ring({ label, time, alarmId }) {
  ringing = true;
  const s = settings.get();
  const tone = alarmId ? toneFor(alarmId) : toneById(s.tone);
  const nativeSound = native.isNative(); // no APK o som já toca pelo despertador do celular
  showRing({
    label,
    time,
    mode: s.dismiss,
    tone,
    soft: s.soft,
    nativeSound,
    onSnooze: () => {
      ignoreNativeUntil = Date.now() + 4000;
      if (nativeSound) native.snooze(SNOOZE_MINUTES, tone, s.soft);
      else snoozeUntil = Date.now() + SNOOZE_MINUTES * 60_000;
      ringing = false;
    },
    onDismiss: () => {
      ignoreNativeUntil = Date.now() + 4000;
      if (nativeSound) native.stopRinging();
      const a = alarmId && store.getAlarms().find((x) => x.id === alarmId);
      if (a && a.days.length === 0) store.patchAlarm(a.id, { enabled: false }); // alarme de uma vez só
      sleep.wakeUp();
      ringing = false;
    },
  });
}

// No navegador o app confere os horários; no APK quem toca é o despertador do celular.
function checkAlarms() {
  if (ringing || native.isNative()) return;
  const hhmm = toHHMM(now);
  const stamp = `${now.toDateString()} ${hhmm}`;

  if (snoozeUntil && now.getTime() >= snoozeUntil) {
    snoozeUntil = null;
    ring({ label: "Soneca acabou! ⏰", time: hhmm });
    return;
  }

  if (lastFired === stamp || now.getSeconds() > 30) return;
  const due = store.getAlarms().find((a) => a.enabled && a.time === hhmm && (a.days.length === 0 || a.days.includes(now.getDay())));
  if (due) {
    lastFired = stamp;
    ring({ label: due.label, time: due.time, alarmId: due.id });
  }
}

// No APK: se o despertador do celular está tocando, mostra a tela de acordar.
async function pollNative() {
  if (!native.isNative() || ringing || polling || Date.now() < ignoreNativeUntil) return;
  polling = true;
  try {
    const r = await native.getRinging();
    if (r && r.ringing && !ringing) ring({ label: r.label || "Acordar", time: r.time || toHHMM(new Date()), alarmId: r.alarmId || null });
  } finally {
    polling = false;
  }
}

function tick() {
  now = new Date();
  renderClock();
  renderHero();
  checkAlarms();
  pollNative();
}

// ---------- começar ----------
renderAccount();
renderClock();
renderList();
renderHero();
setInterval(tick, 1000);

const disableAlarm = (id) => store.patchAlarm(id, { enabled: false });

(async function startNative() {
  await native.init();
  await native.expireOnce(store.getAlarms, disableAlarm);
  native.syncNative(store.getAlarms());
  native.setBedtime(settings.get().bedtimeOn, settings.get().bedtime);
})();

document.addEventListener("visibilitychange", () => {
  if (document.hidden) return;
  native.expireOnce(store.getAlarms, disableAlarm);
  pollNative();
});

(async function start() {
  await initSupabase();
  if (!supabase) return;
  const { data } = await supabase.auth.getSession();
  session = data.session;
  renderAccount();
  store.setUser(session ? session.user.id : null);
  supabase.auth.onAuthStateChange((_event, s) => {
    session = s;
    renderAccount();
    store.setUser(s ? s.user.id : null);
  });
})();
