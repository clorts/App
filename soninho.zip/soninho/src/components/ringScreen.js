import { STARS_NEEDED } from "../config.js";
import { startMelody, stopMelody } from "../sound.js";
import { C, anim, h } from "../ui.js";
import { Mascot } from "./mascot.js";

const randomSpot = () => ({ x: 8 + Math.random() * 78, y: 8 + Math.random() * 40 });

// Para desligar, é preciso pegar 5 estrelinhas ⭐ (assim ninguém volta a dormir!)
export function showRing({ label, time, onDismiss, onSnooze }) {
  let caught = 0;
  let spot = randomSpot();
  let finished = false;

  const root = h("div", {
    style: {
      position: "fixed",
      inset: "0",
      zIndex: "50",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "24px",
      textAlign: "center",
      background: `linear-gradient(to bottom, ${C.candy200}, ${C.candy100}, ${C.skySoft})`,
    },
  });
  document.body.append(root);
  startMelody();

  function close() {
    stopMelody();
    root.remove();
  }

  function catchStar() {
    caught += 1;
    if (caught >= STARS_NEEDED) {
      finished = true;
      stopMelody();
      render();
      setTimeout(() => {
        close();
        onDismiss();
      }, 700);
    } else {
      spot = randomSpot();
      render();
    }
  }

  function render() {
    const done = caught >= STARS_NEEDED;
    root.replaceChildren();

    if (!done) {
      root.append(
        anim(
          h(
            "button",
            {
              "aria-label": "Pegar estrela",
              onClick: catchStar,
              style: { position: "absolute", left: `${spot.x}%`, top: `${spot.y}%`, border: "none", background: "none", cursor: "pointer", fontSize: "48px" },
            },
            "⭐"
          ),
          "pop"
        )
      );
    }

    root.append(
      h("div", { style: { fontSize: "60px", fontWeight: "900", color: C.slate700 } }, time),
      h("div", { style: { marginBottom: "16px", fontSize: "20px", fontWeight: "800", color: C.candy600 } }, label),
      Mascot({ mood: done ? "happy" : "ringing", size: 240 }),
      h(
        "p",
        { style: { margin: "16px 0 0", fontSize: "18px", fontWeight: "900", color: C.slate600 } },
        done ? "Bom diaaa! 🌞" : `Pegue as estrelinhas! ${caught}/${STARS_NEEDED}`
      )
    );

    if (!done) {
      root.append(
        h(
          "button",
          {
            onClick: () => {
              if (finished) return;
              close();
              onSnooze();
            },
            style: { marginTop: "24px", border: "none", cursor: "pointer", fontFamily: "inherit", fontWeight: "900", fontSize: "16px", padding: "12px 24px", borderRadius: "999px", background: "rgba(255,255,255,.8)", color: C.slate500, boxShadow: "0 4px 6px -1px rgba(0,0,0,.1)" },
          },
          "Mais 5 minutinhos 😴"
        )
      );
    }
  }

  render();
}
