import * as sleep from "../sleep.js";
import { pad } from "../utils.js";
import { C, buttonBase, h } from "../ui.js";

const fmtHours = (hours) => `${Math.floor(hours)}h${pad(Math.round((hours % 1) * 60) % 60)}`;
const DAYS = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];

// Cartão "Meu sono": botão de dormir, últimas noites e média.
export function SleepCard() {
  const root = h("section", {
    style: { marginTop: "24px", borderRadius: "24px", padding: "16px", background: C.white, boxShadow: "0 4px 6px -1px rgba(0,0,0,.1)" },
  });

  const action = (text, onClick, primary = true) =>
    h(
      "button",
      {
        onClick,
        style: { ...buttonBase, padding: "10px 18px", borderRadius: "999px", background: primary ? C.candy500 : C.slate100, color: primary ? C.onPink : C.slate500, marginRight: "8px" },
      },
      text
    );

  function render() {
    const { start, log } = sleep.getSleep();
    const last = log.slice(-7);
    const avg = last.length > 0 ? last.reduce((sum, e) => sum + sleep.hoursOf(e), 0) / last.length : 0;

    const bars = last.map((e) => {
      const hours = sleep.hoursOf(e);
      return h(
        "div",
        { style: { display: "flex", flexDirection: "column", alignItems: "center", gap: "4px", flex: "1" } },
        h("div", { style: { fontSize: "11px", fontWeight: "800", color: C.slate500 } }, fmtHours(hours)),
        h("div", { style: { width: "70%", height: `${Math.max(6, Math.min(hours, 10) * 8)}px`, borderRadius: "8px", background: hours >= 7 ? C.candy500 : C.candy400, opacity: hours >= 7 ? "1" : ".7" } }),
        h("div", { style: { fontSize: "11px", fontWeight: "800", color: C.slate400 } }, DAYS[new Date(e.end).getDay()])
      );
    });

    const status = start
      ? h("p", { style: { margin: "0 0 12px", fontWeight: "800", color: C.slate600 } }, `Dormindo desde ${pad(new Date(start).getHours())}:${pad(new Date(start).getMinutes())} 💤 Ao desligar o alarme, eu conto suas horas.`)
      : h("p", { style: { margin: "0 0 12px", fontWeight: "700", color: C.slate500 } }, "Toque em “Fui dormir” antes de deitar. Quando você desligar o alarme, eu conto quanto você dormiu.");

    const buttons = start
      ? h("div", {}, action("Acordei ☀️", () => sleep.wakeUp()), action("Cancelar", () => sleep.cancelBed(), false))
      : h("div", {}, action("Fui dormir 🌙", () => sleep.goToBed()));

    root.replaceChildren(
      h("div", { style: { marginBottom: "8px", fontSize: "18px", fontWeight: "900", color: C.candy600 } }, "Meu sono 🌙"),
      status,
      buttons,
      last.length > 0
        ? h(
            "div",
            { style: { marginTop: "16px" } },
            h("div", { style: { display: "flex", alignItems: "flex-end", gap: "6px", minHeight: "110px" } }, bars),
            h("p", { style: { margin: "12px 0 0", textAlign: "center", fontSize: "14px", fontWeight: "800", color: C.slate500 } }, `Média das últimas noites: ${fmtHours(avg)}`)
          )
        : null
    );
  }

  sleep.subscribe(render);
  render();
  return root;
}
