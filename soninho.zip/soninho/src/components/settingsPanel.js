import * as settings from "../settings.js";
import { toneById } from "../tones.js";
import { C, buttonBase, chip, h, inputStyle, modal, paintChip } from "../ui.js";
import { showConsent } from "../consent.js";
import { legalLinks } from "../legal.js";
import { MASCOTS } from "./mascot.js";
import { openTonePicker } from "./tonePicker.js";

const label = (text) =>
  h("div", { style: { marginBottom: "8px", fontSize: "12px", fontWeight: "800", textTransform: "uppercase", letterSpacing: ".05em", color: C.slate400 } }, text);

// Um grupo de botões onde só um fica escolhido.
function group(title, key, options) {
  const chips = options.map((o) =>
    chip(o.label, settings.get()[key] === o.value, () => {
      settings.set({ [key]: o.value });
      paint();
    })
  );
  const paint = () => chips.forEach((c, i) => paintChip(c, settings.get()[key] === options[i].value));
  return h("div", { style: { marginBottom: "18px" } }, label(title), h("div", { style: { display: "flex", flexWrap: "wrap", gap: "8px" } }, ...chips));
}

export function openSettings() {
  const close = () => overlay.remove();

  const toneBtn = h("button", {
    onClick: () =>
      openTonePicker({
        current: settings.get().tone,
        onPick: (id) => {
          settings.set({ tone: id });
          toneBtn.textContent = `🎵 ${toneById(id).name}`;
        },
      }),
    style: { ...buttonBase, fontSize: "14px", padding: "8px 14px", borderRadius: "999px", background: C.candy100, color: C.candy600 },
  });
  toneBtn.textContent = `🎵 ${toneById(settings.get().tone).name}`;

  const bedtimeInput = h("input", {
    type: "time",
    value: settings.get().bedtime,
    onChange: (e) => settings.set({ bedtime: e.target.value || "22:30" }),
    style: { ...inputStyle, width: "auto", marginBottom: "0", marginTop: "10px", display: settings.get().bedtimeOn ? "block" : "none" },
  });
  const bedtime = group("Lembrete de hora de dormir 🌙", "bedtimeOn", [
    { value: false, label: "Desligado" },
    { value: true, label: "Ligado" },
  ]);
  bedtime.append(bedtimeInput);
  bedtime.addEventListener("click", () => {
    bedtimeInput.style.display = settings.get().bedtimeOn ? "block" : "none";
  });

  const body = h(
    "div",
    {},
    group("Tema", "theme", [
      { value: "claro", label: "Claro ☀️" },
      { value: "escuro", label: "Escuro 🌙" },
    ]),
    group("Mascote", "mascot", MASCOTS),
    group("Como desligar o alarme", "dismiss", [
      { value: "stars", label: "Estrelinhas ⭐" },
      { value: "math", label: "Continhas 🧮" },
      { value: "shake", label: "Balançar 📳" },
      { value: "phrase", label: "Frase ✍️" },
    ]),
    group("Volume do alarme", "soft", [
      { value: false, label: "Normal" },
      { value: true, label: "Suave (vai subindo)" },
    ]),
    h("div", { style: { marginBottom: "18px" } }, label("Toque padrão"), toneBtn),
    bedtime,
    legalLinks(),
    h("div", { style: { textAlign: "center", margin: "0 0 14px", fontSize: "12px", fontWeight: "800" } }, h("a", { href: "#", onClick: (e) => { e.preventDefault(); showConsent(); }, style: { color: C.slate500, textDecoration: "underline" } }, "Preferências de cookies")),
    h("button", { onClick: close, style: { ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", background: C.candy500, color: C.onPink } }, "Pronto")
  );

  const overlay = modal("Ajustes ⚙️", body, close);
  document.body.append(overlay);
}
