import * as settings from "../settings.js";
import { daysToNatal, previewOn, setPreview } from "../natal.js";
import * as store from "../store.js";
import { setToneId } from "../tones.js";
import { C, buttonBase, h, inputStyle, modal } from "../ui.js";
import { openCartao } from "./cartao.js";
import { openSoundMaker } from "./soundMaker.js";
import { hasCustom } from "../customSound.js";

const pad = (n) => String(n).padStart(2, "0");
const btn = (bg, color) => ({ ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginTop: "8px", background: bg, color });

export function openNatalCalendar() {
  const { days, year } = daysToNatal();
  const close = () => overlay.remove();
  const body = h("div");
  const overlay = modal("Calendário de Natal 🎄", body, close);
  let picked = null; // "YYYY-MM-DD"

  function render() {
    const marks = store.getAlarms().filter((a) => a.date && a.date.startsWith(`${year}-12`));
    const first = new Date(year, 11, 1).getDay();
    const cells = [];
    for (let i = 0; i < first; i++) cells.push(h("div"));
    for (let d = 1; d <= 31; d++) {
      const date = `${year}-12-${pad(d)}`;
      const marked = marks.some((m) => m.date === date);
      cells.push(
        h("button", { onClick: () => { picked = date; render(); }, style: { ...buttonBase, fontSize: "14px", height: "40px", borderRadius: "12px", background: picked === date ? C.candy600 : d === 25 ? C.candy500 : marked ? C.skyDeep : C.candy100, color: picked === date || d === 25 || marked ? C.onPink : C.candy600 } }, d === 25 ? "🎅" : marked ? "💖" : String(d))
      );
    }
    const grid = h("div", { style: { display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: "4px" } }, ...["D", "S", "T", "Q", "Q", "S", "S"].map((l) => h("div", { style: { textAlign: "center", fontSize: "12px", fontWeight: "900", color: C.slate400 } }, l)), ...cells);
    const head = h("p", { style: { margin: "0 0 12px", textAlign: "center", fontWeight: "800", color: C.slate600 } }, days === 0 ? "Hoje é Natal! 🎁" : `Faltam ${days} dia${days > 1 ? "s" : ""} para o Natal 🎅`);

    const panel = h("div");
    if (picked) {
      const existing = marks.find((m) => m.date === picked);
      const [, , dd] = picked.split("-");
      if (existing) {
        panel.append(
          h("p", { style: { margin: "12px 0 0", textAlign: "center", fontWeight: "800", color: C.slate600 } }, `Dia ${dd}: alarme às ${existing.time} — ${existing.label}`),
          h("button", { onClick: () => { store.removeAlarm(existing.id); render(); }, style: btn(C.slate100, C.slate500) }, "Tirar este alarme")
        );
      } else {
        const time = h("input", { type: "time", value: "08:00", style: { ...inputStyle, marginTop: "12px", marginBottom: "8px", textAlign: "center", fontSize: "28px" } });
        const label = h("input", { type: "text", maxlength: "30", placeholder: picked.endsWith("-12-25") ? "Acorda, hoje é Natal!" : "Nome (ex: Dia especial)", style: { ...inputStyle, marginBottom: "0" } });
        panel.append(
          h("p", { style: { margin: "12px 0 0", textAlign: "center", fontWeight: "800", color: C.slate600 } }, `Marcar dia ${dd}: o alarme apita nesse dia ⏰`),
          time,
          label,
          h("button", {
            onClick: () => {
              const id = crypto.randomUUID();
              setToneId(id, settings.get().tone);
              store.addAlarm({ id, time: time.value || "08:00", label: label.value.trim() || (picked.endsWith("-12-25") ? "Acorda, hoje é Natal!" : "Dia especial"), days: [], date: picked, tone: settings.get().tone });
              render();
            },
            style: btn(C.candy500, C.onPink),
          }, "Marcar e ligar alarme")
        );
      }
    }

    body.replaceChildren(
      head,
      grid,
      panel,
      h("p", { style: { margin: "14px 0 0", fontSize: "13px", fontWeight: "700", textAlign: "center", color: C.slate500 } }, "No dia 25 o alarme fala “Acorda, hoje é Natal! 🎁” e toca o seu “Ho ho ho!”."),
      h("button", { onClick: () => openSoundMaker({ onSaved: render }), style: btn(C.skySoft, C.slate600) }, hasCustom() ? "🎙️ Trocar meu “Ho ho ho!”" : "🎙️ Gravar meu “Ho ho ho!” (Meu áudio)"),
      h("button", { onClick: openCartao, style: btn(C.candy100, C.candy600) }, "💌 Cartão de Natal animado"),
      h("button", { onClick: () => { setPreview(!previewOn()); render(); }, style: btn(C.candy100, C.candy600) }, previewOn() ? "Desligar tema de Natal" : "👀 Ver o tema de Natal agora"),
      h("button", { onClick: close, style: btn(C.slate100, C.slate500) }, "Fechar")
    );
  }
  render();
  document.body.append(overlay);
}
