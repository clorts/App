import { STARS_NEEDED } from "../config.js";
import { startMelody, stopMelody } from "../sound.js";
import { C, anim, h } from "../ui.js";
import { HINTS, startChallenge } from "./challenges.js";
import { Mascot } from "./mascot.js";

const randomSpot = () => ({ x: 8 + Math.random() * 78, y: 8 + Math.random() * 40 });

// Tela de acordar. Para desligar: estrelinhas, continhas, balançar ou digitar a frase (ajuste da pessoa).
// nativeSound = true quando o som já está tocando pelo despertador do celular.
export function showRing({ label, time, mode = "stars", tone, soft = false, nativeSound = false, onDismiss, onSnooze }) {
  let caught = 0;
  let finished = false;
  let cleanup = () => {};

  const root = h("div", {
    style: {
      position: "fixed",
      inset: "0",
      zIndex: "50",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "24px",
      textAlign: "center",
      background: `linear-gradient(to bottom, ${C.candy200}, ${C.candy100}, ${C.skySoft})`,
    },
  });
  const starLayer = h("div");
  const mascotSlot = h("div");
  const status = h("p", { style: { margin: "16px 0 0", fontSize: "18px", fontWeight: "900", color: C.slate600 } });
  const challengeSlot = h("div", { style: { marginTop: "12px" } });
  const snoozeBtn = h(
    "button",
    {
      onClick: () => {
        if (finished) return;
        close();
        onSnooze();
      },
      style: { marginTop: "24px", border: "none", cursor: "pointer", fontFamily: "inherit", fontWeight: "900", fontSize: "16px", padding: "12px 24px", borderRadius: "999px", background: C.glass8, color: C.slate500, boxShadow: "0 4px 6px -1px rgba(0,0,0,.1)" },
    },
    "Mais 5 minutinhos 😴"
  );

  root.append(
    starLayer,
    h("div", { style: { fontSize: "60px", fontWeight: "900", color: C.slate700 } }, time),
    h("div", { style: { marginBottom: "16px", fontSize: "20px", fontWeight: "800", color: C.candy600 } }, label),
    mascotSlot,
    status,
    challengeSlot,
    snoozeBtn
  );
  document.body.append(root);
  if (!nativeSound) startMelody(tone, soft);

  const setMood = (mood) => mascotSlot.replaceChildren(Mascot({ mood, size: 220 }));

  function close() {
    cleanup();
    stopMelody();
    root.remove();
  }

  function finish() {
    if (finished) return;
    finished = true;
    cleanup();
    stopMelody();
    starLayer.replaceChildren();
    challengeSlot.replaceChildren();
    snoozeBtn.remove();
    setMood("happy");
    status.textContent = "Bom diaaa! 🌞";
    setTimeout(() => {
      root.remove();
      onDismiss();
    }, 700);
  }

  function drawStar() {
    const spot = randomSpot();
    starLayer.replaceChildren(
      anim(
        h(
          "button",
          {
            "aria-label": "Pegar estrela",
            onClick: () => {
              caught += 1;
              if (caught >= STARS_NEEDED) return finish();
              status.textContent = `Pegue as estrelinhas! ${caught}/${STARS_NEEDED}`;
              drawStar();
            },
            style: { position: "absolute", left: `${spot.x}%`, top: `${spot.y}%`, border: "none", background: "none", cursor: "pointer", fontSize: "48px" },
          },
          "⭐"
        ),
        "pop"
      )
    );
  }

  function setup(mode) {
    cleanup();
    cleanup = () => {};
    starLayer.replaceChildren();
    challengeSlot.replaceChildren();
    if (mode === "stars") {
      caught = 0;
      status.textContent = `Pegue as estrelinhas! 0/${STARS_NEEDED}`;
      drawStar();
      return;
    }
    status.textContent = HINTS[mode];
    const challenge = startChallenge(mode, {
      onSolved: finish,
      onFallback: () => setup("stars"),
      onProgress: (text) => (status.textContent = text),
    });
    challengeSlot.append(challenge.el);
    cleanup = challenge.cleanup;
  }

  setMood("ringing");
  setup(mode);
}
