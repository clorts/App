package __PACKAGE__;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

// Guarda os alarmes no celular e agenda cada um com AlarmManager.setAlarmClock
// (exato, funciona com o app fechado e com o celular em repouso).
public class AlarmScheduler {
    private static final String PREFS = "soninho_alarms";
    private static final String KEY_LIST = "list";
    private static final String KEY_CODES = "codes";
    private static final int SNOOZE_CODE = 1;

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static JSONArray readList(Context c) {
        try {
            return new JSONArray(prefs(c).getString(KEY_LIST, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static int codeFor(String id) {
        return 100 + (id.hashCode() & 0x3fffffff);
    }

    private static PendingIntent alarmIntent(Context c, int code, String id, String label, String time, String toneJson, boolean soft) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction("__PACKAGE__.ALARM");
        i.putExtra("id", id);
        i.putExtra("label", label);
        i.putExtra("time", time);
        i.putExtra("tone", toneJson);
        i.putExtra("soft", soft);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static PendingIntent showIntent(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    // Recebe a lista inteira vinda do app (JSON) e reagenda tudo.
    public static void saveAndSchedule(Context c, String json) {
        prefs(c).edit().putString(KEY_LIST, json).apply();
        scheduleAll(c);
    }

    public static synchronized void scheduleAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        String old = prefs(c).getString(KEY_CODES, "");
        if (!old.isEmpty()) {
            for (String s : old.split(",")) {
                try {
                    am.cancel(alarmIntent(c, Integer.parseInt(s), "", "", "", "{}", false));
                } catch (Exception ignored) {
                }
            }
        }

        StringBuilder codes = new StringBuilder();
        JSONArray list = readList(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject a = list.optJSONObject(i);
            if (a == null || !a.optBoolean("enabled", true)) continue;
            String id = a.optString("id", "");
            String time = a.optString("time", "07:00");
            // Dia marcado (calendário de Natal): o app manda o instante exato em "at".
            long at = a.has("at") ? a.optLong("at", -1) : nextTrigger(time, a.optJSONArray("days"));
            if (a.has("at") && at <= System.currentTimeMillis()) continue;
            if (at < 0 || id.isEmpty()) continue;
            JSONObject tone = a.optJSONObject("tone");
            int code = codeFor(id);
            PendingIntent pi = alarmIntent(c, code, id, a.optString("label", "Acordar"), time,
                    tone == null ? "{}" : tone.toString(), a.optBoolean("soft", false));
            try {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, showIntent(c)), pi);
            } catch (Exception e) {
                continue;
            }
            if (codes.length() > 0) codes.append(",");
            codes.append(code);
        }
        prefs(c).edit().putString(KEY_CODES, codes.toString()).apply();
    }

    // Depois que um alarme toca: o de "uma vez só" é desligado e os outros ganham o próximo horário.
    public static void afterFire(Context c, String id) {
        if (id == null || id.isEmpty()) return;
        try {
            JSONArray list = readList(c);
            for (int i = 0; i < list.length(); i++) {
                JSONObject a = list.optJSONObject(i);
                if (a != null && id.equals(a.optString("id", ""))) {
                    JSONArray d = a.optJSONArray("days");
                    if (d == null || d.length() == 0 || a.has("at")) a.put("enabled", false);
                }
            }
            prefs(c).edit().putString(KEY_LIST, list.toString()).apply();
        } catch (Exception ignored) {
        }
        scheduleAll(c);
    }

    public static void scheduleSnooze(Context c, int minutes, String toneJson, boolean soft) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long at = System.currentTimeMillis() + minutes * 60000L;
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(at);
        String time = String.format(Locale.US, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
        PendingIntent pi = alarmIntent(c, SNOOZE_CODE, "", "Soneca acabou! \u23F0", time, toneJson, soft);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, showIntent(c)), pi);
        } catch (Exception ignored) {
        }
    }

    private static long nextTrigger(String time, JSONArray days) {
        try {
            String[] p = time.split(":");
            int hh = Integer.parseInt(p[0]);
            int mm = Integer.parseInt(p[1]);
            long now = System.currentTimeMillis();
            for (int add = 0; add < 8; add++) {
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, hh);
                cal.set(Calendar.MINUTE, mm);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                cal.add(Calendar.DAY_OF_MONTH, add);
                if (cal.getTimeInMillis() <= now) continue;
                if (days != null && days.length() > 0) {
                    int dow = cal.get(Calendar.DAY_OF_WEEK) - 1; // domingo = 0, igual ao JavaScript
                    boolean ok = false;
                    for (int i = 0; i < days.length(); i++) {
                        if (days.optInt(i, -1) == dow) ok = true;
                    }
                    if (!ok) continue;
                }
                return cal.getTimeInMillis();
            }
        } catch (Exception ignored) {
        }
        return -1;
    }
}
