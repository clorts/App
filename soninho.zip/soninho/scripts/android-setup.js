// Roda depois de "npx cap add android": instala o despertador nativo (Java), as permissões,
// o ícone da notificação e a chave fixa de assinatura (para o APK novo instalar por cima do antigo).
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const config = JSON.parse(readFileSync("capacitor.config.json", "utf8"));
const appId = config.appId;
const manifestPath = join("android", "app", "src", "main", "AndroidManifest.xml");
if (!existsSync(manifestPath)) throw new Error("Rode 'npx cap add android' antes deste script.");

// 1) Código Java do despertador
const javaDir = join("android", "app", "src", "main", "java", ...appId.split("."));
mkdirSync(javaDir, { recursive: true });
const templates = join("native", "android");
for (const file of readdirSync(templates).filter((f) => f.endsWith(".java"))) {
  const code = readFileSync(join(templates, file), "utf8").replaceAll("__PACKAGE__", appId);
  writeFileSync(join(javaDir, file), code);
}

// 2) Permissões e componentes no AndroidManifest
const permissions = [
  "android.permission.POST_NOTIFICATIONS",
  "android.permission.SCHEDULE_EXACT_ALARM",
  "android.permission.USE_EXACT_ALARM",
  "android.permission.RECEIVE_BOOT_COMPLETED",
  "android.permission.VIBRATE",
  "android.permission.WAKE_LOCK",
  "android.permission.FOREGROUND_SERVICE",
  "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK",
  "android.permission.USE_FULL_SCREEN_INTENT",
  "android.permission.RECORD_AUDIO",
  "android.permission.MODIFY_AUDIO_SETTINGS",
];

let manifest = readFileSync(manifestPath, "utf8");
const missing = permissions.filter((p) => !manifest.includes(`"${p}"`));
if (missing.length > 0) {
  const lines = missing.map((p) => `    <uses-permission android:name="${p}" />`).join("\n");
  manifest = manifest.replace("<application", `${lines}\n\n    <application`);
}

if (!manifest.includes(".AlarmService")) {
  const components = [
    '        <receiver android:name=".AlarmReceiver" android:exported="false" />',
    '        <receiver android:name=".BootReceiver" android:exported="true">',
    "            <intent-filter>",
    '                <action android:name="android.intent.action.BOOT_COMPLETED" />',
    '                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />',
    "            </intent-filter>",
    "        </receiver>",
    '        <service android:name=".AlarmService" android:exported="false" android:foregroundServiceType="mediaPlayback" />',
  ].join("\n");
  manifest = manifest.replace("</application>", `${components}\n    </application>`);
}
writeFileSync(manifestPath, manifest);

// 3) Ícone de nuvem (branco) para a barra de notificações
const drawableDir = join("android", "app", "src", "main", "res", "drawable");
mkdirSync(drawableDir, { recursive: true });
const cloud = [
  '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
  '    android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">',
  '  <path android:fillColor="#FFFFFFFF"',
  '      android:pathData="M19.35,10.04C18.67,6.59 15.64,4 12,4 9.11,4 6.6,5.64 5.35,8.04 2.34,8.36 0,10.91 0,14c0,3.31 2.69,6 6,6h13c2.76,0 5,-2.24 5,-5 0,-2.64 -2.05,-4.78 -4.65,-4.96z" />',
  "</vector>",
  "",
].join("\n");
writeFileSync(join(drawableDir, "ic_stat_soninho.xml"), cloud);

// 3b) Ícone do app (nuvem) e cor de fundo do ícone adaptativo
const resDir = join("android", "app", "src", "main", "res");
if (existsSync(join("native", "res"))) {
  for (const d of readdirSync(join("native", "res"))) {
    mkdirSync(join(resDir, d), { recursive: true });
    for (const f of readdirSync(join("native", "res", d))) copyFileSync(join("native", "res", d, f), join(resDir, d, f));
  }
  const valuesDir = join(resDir, "values");
  mkdirSync(valuesDir, { recursive: true });
  writeFileSync(join(valuesDir, "ic_launcher_background.xml"), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#FF8FB8</color>\n</resources>\n');
}

// 4) Chave de assinatura fixa: assim cada APK novo instala por cima do anterior sem apagar nada
const keystore = join("native", "debug.keystore");
if (existsSync(keystore)) {
  const dir = join(homedir(), ".android");
  mkdirSync(dir, { recursive: true });
  copyFileSync(keystore, join(dir, "debug.keystore"));
}

console.log("Android configurado");
