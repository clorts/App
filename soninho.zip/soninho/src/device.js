// Conta presa ao aparelho: ao instalar o app de novo no mesmo celular, entra na última conta usada.
// A chave do aparelho vem do ANDROID_ID (não muda ao desinstalar). Precisa de supabase/002_device_session.sql.
import * as native from "./native.js";
import { supabase } from "./supabase.js";

let key = null;

export async function initDevice() {
  key = await native.getDeviceKey();
}

export async function saveDeviceSession(session) {
  if (!supabase || !key || !session || !session.refresh_token) return;
  await supabase.rpc("soninho_save_device", { p_key: key, p_token: session.refresh_token, p_user: session.user.id });
}

export async function restoreDeviceSession() {
  if (!supabase || !key) return null;
  const { data, error } = await supabase.rpc("soninho_get_device", { p_key: key });
  if (error || !data) return null;
  const res = await supabase.auth.refreshSession({ refresh_token: data });
  return res.data && res.data.session ? res.data.session : null;
}

// Chamar ANTES de sair da conta (ainda logado): quem sai de propósito não volta sozinho depois.
export async function forgetDevice() {
  if (!supabase || !key) return;
  await supabase.rpc("soninho_clear_device", { p_key: key });
}
