import { MAX_SECONDS, convertToWav, startRecording, validateFile } from "../audioTools.js";
import { clearCustom, setCustomB64 } from "../customSound.js";
import * as native from "../native.js";
import { previewTone, stopMelody } from "../sound.js";
import { C, buttonBase, h, inputStyle, modal } from "../ui.js";

const btn = (bg, color) => ({ ...buttonBase, width: "100%", padding: "12px", borderRadius: "16px", marginBottom: "10px", background: bg, color });

// Criar o "Meu áudio": gravar no microfone ou escolher um áudio/vídeo que já está no aparelho.
export function openSoundMaker({ onSaved }) {
  let pending = null; // { b64, seconds } já convertido, ainda não salvo
  let recorder = null;
  let source = null; // ArrayBuffer original (para refazer com outro "começar em")
  const close = () => {
    stopMelody();
    overlay.remove();
  };

  const msg = h("p", { style: { margin: "0 0 12px", textAlign: "center", fontSize: "14px", fontWeight: "700", color: C.candy600, minHeight: "20px" } });
  const startAt = h("input", { type: "number", min: "0", value: "0", style: { ...inputStyle, width: "90px", display: "inline-block", marginBottom: "0", marginLeft: "8px" } });
  const file = h("input", { type: "file", accept: "audio/*,video/*", style: { display: "none" } });
  const recBtn = h("button", { style: btn(C.candy500, C.onPink) }, "🎙️ Gravar agora (até 30 s)");
  const pickBtn = h("button", { style: btn(C.candy100, C.candy600) }, "📁 Escolher áudio ou vídeo do celular");
  const playBtn = h("button", { style: { ...btn(C.skySoft, C.slate600), display: "none" } }, "▶️ Ouvir");
  const saveBtn = h("button", { style: { ...btn(C.candy500, C.onPink), display: "none" } }, "Salvar como meu toque");
  const removeBtn = h("button", { style: btn(C.slate100, C.slate500) }, "🗑️ Remover meu áudio");

  async function convert(buf) {
    msg.textContent = "Preparando o som… ⏳";
    try {
      pending = await convertToWav(buf.slice(0), Number(startAt.value) || 0);
      msg.textContent = `Pronto! ${Math.round(pending.seconds)} s de áudio. Ouça e salve. ✅`;
      playBtn.style.display = saveBtn.style.display = "block";
    } catch (e) {
      pending = null;
      msg.textContent = e.message;
    }
  }

  file.addEventListener("change", async () => {
    const f = file.files[0];
    file.value = "";
    if (!f) return;
    try {
      await validateFile(f);
    } catch (e) {
      msg.textContent = e.message;
      return;
    }
    source = await f.arrayBuffer();
    await convert(source);
  });
  startAt.addEventListener("change", () => source && convert(source));
  pickBtn.addEventListener("click", () => file.click());

  async function finishRecording() {
    const buf = await recorder.stop();
    recorder = null;
    recBtn.textContent = "🎙️ Gravar agora (até 30 s)";
    source = buf;
    startAt.value = "0";
    await convert(buf);
  }
  recBtn.addEventListener("click", async () => {
    if (recorder) return finishRecording();
    msg.textContent = "";
    try {
      recorder = await startRecording((s) => (recBtn.textContent = `⏹️ Parar (${s}/${MAX_SECONDS} s)`), finishRecording);
      recBtn.textContent = `⏹️ Parar (0/${MAX_SECONDS} s)`;
    } catch (e) {
      msg.textContent = e.message;
    }
  });

  playBtn.addEventListener("click", () => {
    if (!pending) return;
    try {
      setCustomB64(pending.b64);
    } catch {
      msg.textContent = "Sem espaço para guardar esse áudio. 😢";
      return;
    }
    previewTone({ custom: true });
  });

  saveBtn.addEventListener("click", async () => {
    if (!pending) return;
    try {
      setCustomB64(pending.b64);
      if (native.isNative()) await native.saveCustomSound(pending.b64);
    } catch {
      clearCustom();
      msg.textContent = "Não consegui salvar esse áudio. 😢";
      return;
    }
    close();
    onSaved();
  });

  removeBtn.addEventListener("click", async () => {
    clearCustom();
    await native.deleteCustomSound();
    close();
    onSaved();
  });

  const body = h(
    "div",
    {},
    h("p", { style: { margin: "0 0 14px", textAlign: "center", fontSize: "14px", fontWeight: "700", color: C.slate500 } }, "Grave sua voz ou use o som de um áudio/vídeo que você já baixou. Só os primeiros 30 s são usados."),
    recBtn,
    pickBtn,
    h("div", { style: { margin: "0 0 12px", fontSize: "14px", fontWeight: "800", color: C.slate500, textAlign: "center" } }, "Começar no segundo:", startAt),
    msg,
    playBtn,
    saveBtn,
    removeBtn,
    file
  );
  const overlay = modal("Meu áudio 🎙️", body, close);
  document.body.append(overlay);
}
