# Soninho ☁️ — Despertador Fofo

JavaScript puro + Supabase + Capacitor (APK) + despertador nativo em Java. Sem arquivos .html/.css: a página é gerada pelo `build.js`
e todo o visual é feito em JavaScript.

## Gerar o APK (pelo GitHub, sem computador)
1. Crie um repositório no GitHub e envie este zip (ou os arquivos).
2. Crie o arquivo `.github/workflows/apk.yml` (já vem neste projeto; se enviou só o zip, crie esse arquivo colando o conteúdo).
3. Aba **Actions** → "Gerar APK" → espere ficar verde (uns 5-8 min).
4. Aba **Releases** (página inicial do repositório) → baixe `soninho.apk` e instale.

## Netlify (versão site)
Build command: `node build.js` — Publish directory: `dist`.

## Testar no computador
`node build.js && node serve.js` e abra http://localhost:5173

## Supabase
URL e chave publishable ficam em `src/config.js`. A tabela já foi criada (supabase/001_soninho.sql).
Nunca coloque a chave secret neste projeto.

## O que tem
- Despertador nativo: toca em loop com o app fechado e a tela bloqueada (serviço em primeiro plano + tela por cima do bloqueio).
- Toques (melodias), volume suave, 4 jeitos de desligar (estrelinhas, continhas, balançar, frase).
- Meu sono (histórico), lembrete de hora de dormir, tema escuro e 3 mascotes.
- Código nativo em `native/android/*.java`, instalado no projeto Android por `scripts/android-setup.js`.
- `native/debug.keystore`: chave fixa para o APK novo instalar por cima do antigo.

## Novidades da versão 5
- **Ícone e entrada**: ícone de nuvem (`assets/icone-soninho.png`, tamanhos em `native/res/`) e animação de abertura (`src/splash.js`).
- **Meu áudio**: em Escolher toque > "Gravar ou escolher meu áudio". Grava no microfone ou usa o som de um áudio/vídeo do celular. Máx. 30 s, convertido para WAV no aparelho. Valida extensão, tipo, tamanho (áudio 15 MB, vídeo 60 MB) e os primeiros bytes do arquivo.
- **Conta presa ao aparelho**: reinstalou o app no mesmo celular, entra na última conta usada. "Sair" desfaz isso. **Rode `supabase/002_device_session.sql` no SQL Editor do Supabase** (sem isso o app funciona, mas não lembra a conta).
- **Legal**: Política de Privacidade, Termos de Uso, aviso de cookies (a fonte do Google só carrega se aceitar) e botão "Apagar minha conta e meus dados". **Troque `CONTACT_EMAIL` em `src/config.js`** e peça a um advogado para revisar os textos em `src/legal.js`.

## Novidades da versão 6 (Natal 🎄)
- **Calendário de Natal** (botão 🎄 Natal): marque um dia de dezembro e o alarme apita nesse dia (vale no APK, com o app fechado).
- **Dia 25**: o tema muda para Natal (neve, vermelho e verde, mascote com chapéu) às 00:00 e some às 00:00 do dia 26. Todo alarme do dia acorda com "Acorda, hoje é Natal! 🎁" e toca o "Ho ho ho!" gravado em **Meu áudio** (sem gravação, o celular fala). Botão "Ver o tema de Natal agora" para testar.
- **3 novos personagens**: Nuvi Noel, Gatinho Noel e Ursinho Noel (`src/assets/skins/`, fundo removido). Em Ajustes > Mascote. No dia 25 os mascotes viram a versão Noel sozinhos.
- **Compartilhar** (📤) e **Cartão de Natal animado** (abre por link no WhatsApp ou vai como imagem). **Preencha `SHARE_URL` em `src/config.js`** com o link do seu site (necessário no APK).
- **Conta**: alarmes, dias marcados e toques ficam salvos na conta (também numa cópia no aparelho). **Rode `supabase/003_natal.sql`** no SQL Editor.
- **Som mais alto**: o APK coloca o volume do alarme do celular no máximo, as melodias ficaram bem mais fortes, e há dois toques novos: "Despertador forte" e "Sirene". O modo suave agora chega ao volume máximo em 15 s.
