import { DAY_LABELS } from "../config.js";
import { C, h } from "../ui.js";

export function alarmCard(alarm, { onToggle, onDelete }) {
  const on = alarm.enabled;

  const days =
    alarm.days.length === 0
      ? h("span", { style: { fontSize: "12px", fontWeight: "700", color: C.slate400 } }, "só uma vez")
      : DAY_LABELS.map((label, d) =>
          h(
            "span",
            { style: { fontSize: "12px", fontWeight: "900", color: alarm.days.includes(d) ? C.candy500 : C.slate300 } },
            label
          )
        );

  const toggle = h(
    "button",
    {
      "aria-label": "Ligar ou desligar",
      onClick: onToggle,
      style: {
        position: "relative",
        width: "56px",
        height: "32px",
        border: "none",
        borderRadius: "999px",
        cursor: "pointer",
        background: on ? C.candy500 : "#e2e8f0",
        transition: "background .2s",
      },
    },
    h("span", {
      style: {
        position: "absolute",
        top: "4px",
        left: on ? "28px" : "4px",
        width: "24px",
        height: "24px",
        borderRadius: "999px",
        background: C.white,
        boxShadow: "0 1px 3px rgba(0,0,0,.25)",
        transition: "left .2s",
      },
    })
  );

  return h(
    "div",
    {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        borderRadius: "24px",
        padding: "16px",
        background: on ? C.white : "rgba(255,255,255,.6)",
        opacity: on ? "1" : ".7",
        boxShadow: "0 4px 6px -1px rgba(0,0,0,.1)",
      },
    },
    h(
      "div",
      {},
      h("div", { style: { fontSize: "36px", fontWeight: "900", letterSpacing: "-0.025em", color: C.slate700 } }, alarm.time),
      h("div", { style: { fontSize: "14px", fontWeight: "800", color: C.candy500 } }, alarm.label),
      h("div", { style: { display: "flex", gap: "4px", marginTop: "4px" } }, days)
    ),
    h(
      "div",
      { style: { display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "12px" } },
      toggle,
      h(
        "button",
        {
          onClick: onDelete,
          style: { border: "none", background: "none", cursor: "pointer", fontFamily: "inherit", fontSize: "12px", fontWeight: "700", color: C.slate300 },
        },
        "apagar 🗑️"
      )
    )
  );
}
