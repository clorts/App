import { CONTACT_EMAIL, LEGAL_UPDATED } from "./config.js";
import { C, h, modal } from "./ui.js";

const PRIVACY = [
  ["Quem somos", `O Soninho é um despertador. Contato para assuntos de privacidade: ${CONTACT_EMAIL}. Atualizado em ${LEGAL_UPDATED}.`],
  ["Dados que usamos", "Conta (opcional): e-mail e senha (a senha é guardada criptografada pelo Supabase). Alarmes: nome, horário e dias. Aparelho (Android): um código gerado a partir do identificador do aparelho (não o identificador em si) e a chave de sessão, para você entrar sozinho na última conta ao reinstalar o app. Ajustes, histórico de sono e seu áudio próprio ficam apenas no seu aparelho."],
  ["Microfone, áudio e vídeo", "O microfone só é usado quando você toca em Gravar. Áudios e vídeos escolhidos são processados no próprio aparelho; o app guarda só um áudio WAV de até 30 s, que não é enviado para a nuvem. Nunca lemos seus outros arquivos."],
  ["Para que usamos", "Fazer o app funcionar: tocar alarmes, sincronizar seus alarmes entre aparelhos e manter você conectado. Não vendemos dados, não temos publicidade e não usamos ferramentas de análise (como Google Analytics)."],
  ["Com quem compartilhamos", "Supabase (login e banco de dados dos alarmes). Para carregar o app, uma biblioteca vem do servidor esm.sh. Se você aceitar os cookies, a fonte do Google Fonts também é carregada. Esses serviços podem receber seu endereço IP."],
  ["Por quanto tempo", "Enquanto sua conta existir. Ao apagar a conta, removemos e-mail, alarmes e a chave do aparelho."],
  ["Seus direitos (LGPD)", `Você pode acessar, corrigir e apagar seus dados, e revogar consentimentos. Em Minha conta há o botão Apagar minha conta e meus dados. Outros pedidos: ${CONTACT_EMAIL}.`],
  ["Crianças", "O Soninho não é voltado a menores de 13 anos. Menores de 18 devem usar com autorização de um responsável."],
  ["Mudanças", "Se esta política mudar, a data acima será atualizada."],
];

const TERMS = [
  ["Aceite", "Ao criar uma conta ou usar o Soninho, você concorda com estes termos e com a Política de Privacidade."],
  ["Uso do app", "Use o app apenas para fins pessoais e legais. É proibido tentar invadir, sobrecarregar ou enviar arquivos maliciosos. Só aceitamos arquivos de áudio e vídeo nos formatos e tamanhos indicados na tela."],
  ["Seu conteúdo", "Use apenas áudios e vídeos seus ou que você tem direito de usar. Você é responsável pelo que grava ou escolhe."],
  ["Alarme não é garantia", "O Soninho se esforça para tocar no horário, mas o Android pode limitar apps (economia de bateria, celular desligado, volume zerado, falta de permissão). Não use como único meio para compromissos críticos, como remédios, voos ou provas."],
  ["Conta", "Cuide da sua senha. Você pode apagar sua conta a qualquer momento em Minha conta."],
  ["Responsabilidade", "O app é oferecido como está, sem garantia de funcionamento ininterrupto. Na extensão permitida pela lei, não nos responsabilizamos por perdas decorrentes de alarmes que não tocaram."],
  ["Lei e contato", `Valem as leis do Brasil. Dúvidas: ${CONTACT_EMAIL}. Atualizado em ${LEGAL_UPDATED}.`],
];

const COOKIES = [
  ["O que guardamos", "O Soninho usa o armazenamento local do seu aparelho (localStorage) para guardar alarmes, ajustes, toque, histórico de sono, sessão de login e seu áudio próprio. É essencial: sem isso o app não funciona."],
  ["Opcional", "A fonte Nunito do Google Fonts. Se você escolher Só o essencial, usamos a fonte padrão do celular e nada é pedido ao Google."],
  ["Sem rastreio", "Não usamos cookies de publicidade nem de análise."],
];

const DOCS = { privacy: ["Política de Privacidade 🔒", PRIVACY], terms: ["Termos de Uso 📜", TERMS], cookies: ["Cookies 🍪", COOKIES] };

export function openLegal(kind) {
  const [title, sections] = DOCS[kind];
  const body = h(
    "div",
    { style: { fontSize: "14px", lineHeight: "1.5", color: C.slate600 } },
    ...sections.map(([t, p]) => h("div", { style: { marginBottom: "14px" } }, h("div", { style: { fontWeight: "900", color: C.candy600, marginBottom: "2px" } }, t), h("div", { style: { fontWeight: "600" } }, p)))
  );
  const overlay = modal(title, body, () => overlay.remove());
  document.body.append(overlay);
}

export const legalLinks = () =>
  h(
    "div",
    { style: { display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "4px 14px", margin: "0 0 14px", fontSize: "12px", fontWeight: "800" } },
    ...[["privacy", "Privacidade"], ["terms", "Termos de Uso"], ["cookies", "Cookies"]].map(([k, l]) =>
      h("a", { href: "#", onClick: (e) => { e.preventDefault(); openLegal(k); }, style: { color: C.slate500, textDecoration: "underline" } }, l)
    )
  );
