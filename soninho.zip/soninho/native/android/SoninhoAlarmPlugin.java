package __PACKAGE__;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;

// Ponte entre o JavaScript do Soninho e o despertador nativo do Android.
@CapacitorPlugin(name = "SoninhoAlarm")
public class SoninhoAlarmPlugin extends Plugin {

    @PluginMethod
    public void schedule(PluginCall call) {
        JSArray alarms = call.getArray("alarms");
        AlarmScheduler.saveAndSchedule(getContext(), alarms == null ? "[]" : alarms.toString());
        call.resolve();
    }

    @PluginMethod
    public void getRinging(PluginCall call) {
        JSObject res = new JSObject();
        JSONObject cur = AlarmService.ringing;
        if (cur != null) {
            res.put("ringing", true);
            res.put("alarmId", cur.optString("alarmId", ""));
            res.put("label", cur.optString("label", ""));
            res.put("time", cur.optString("time", ""));
        } else {
            res.put("ringing", false);
        }
        call.resolve(res);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        AlarmService.stopNow(getContext());
        call.resolve();
    }

    @PluginMethod
    public void snooze(PluginCall call) {
        int minutes = call.getInt("minutes", 5);
        JSObject tone = call.getObject("tone");
        boolean soft = call.getBoolean("soft", false);
        AlarmService.stopNow(getContext());
        AlarmScheduler.scheduleSnooze(getContext(), minutes, tone == null ? "{}" : tone.toString(), soft);
        call.resolve();
    }
}
