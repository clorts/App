package __PACKAGE__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import org.json.JSONArray;
import org.json.JSONObject;

// Serviço que fica tocando o alarme em loop (som + vibração) até a pessoa acordar de verdade no app.
public class AlarmService extends Service {
    private static final String CHANNEL = "soninho_toque";
    private static final int NOTIF_ID = 4242;
    private static final long MAX_MS = 5 * 60 * 1000L;

    // Dados do alarme que está tocando agora (o app lê isso para mostrar a tela de acordar).
    public static volatile JSONObject ringing = null;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wake;
    private Vibrator vibrator;
    private Thread synth;
    private volatile boolean playing = false;
    private MediaPlayer player;
    private volatile long startedAt = 0;
    private volatile boolean soft = false;
    private volatile String curTone = "{}";

    private final Runnable timeout = new Runnable() {
        @Override
        public void run() {
            stopSelf();
        }
    };

    private final Runnable rampTick = new Runnable() {
        @Override
        public void run() {
            if (player != null) {
                float g = gain();
                try {
                    player.setVolume(g, g);
                } catch (Exception ignored) {
                }
                handler.postDelayed(this, 500);
            }
        }
    };

    public static java.io.File customFile(Context c) {
        return new java.io.File(c.getFilesDir(), "meu_audio.wav");
    }

    public static void stopNow(Context c) {
        ringing = null;
        c.stopService(new Intent(c, AlarmService.class));
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if ("ADIAR".equals(intent.getAction())) {
            AlarmScheduler.scheduleSnooze(this, 5, curTone, soft);
            stopNow(this);
            return START_NOT_STICKY;
        }
        String id = nz(intent.getStringExtra("id"), "");
        String label = nz(clean(intent.getStringExtra("label")), "Acordar");
        String time = nz(intent.getStringExtra("time"), "");
        String toneJson = nz(intent.getStringExtra("tone"), "{}");
        soft = intent.getBooleanExtra("soft", false);
        curTone = toneJson;

        ensureChannel();
        Notification n = buildNotification(label, time);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }

        try {
            JSONObject r = new JSONObject();
            r.put("alarmId", id);
            r.put("label", label);
            r.put("time", time);
            ringing = r;
        } catch (Exception ignored) {
        }

        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (wake == null && pm != null) wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "soninho:alarme");
            if (wake != null && !wake.isHeld()) wake.acquire(MAX_MS + 10000L);
        } catch (Exception ignored) {
        }

        stopSound();
        startedAt = System.currentTimeMillis();
        startVibration();
        startSound(toneJson);

        handler.removeCallbacks(timeout);
        handler.postDelayed(timeout, MAX_MS);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopSound();
        try {
            if (vibrator != null) vibrator.cancel();
        } catch (Exception ignored) {
        }
        try {
            if (wake != null && wake.isHeld()) wake.release();
        } catch (Exception ignored) {
        }
        ringing = null;
        stopForeground(true);
        super.onDestroy();
    }

    // Tira emojis e símbolos do texto (a notificação usa só ícones).
    private static String clean(String s) {
        if (s == null) return null;
        return s.replaceAll("[\\p{So}\\p{Cs}\\uFE0F\\u200D]", "").trim();
    }

    private static String nz(String s, String fallback) {
        return (s == null || s.isEmpty()) ? fallback : s;
    }

    // Volume "suave": começa mais baixo e chega ao máximo em 15 segundos.
    private float gain() {
        if (!soft) return 1f;
        float t = (System.currentTimeMillis() - startedAt) / 15000f;
        return Math.min(1f, 0.25f + 0.75f * t);
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Alarme tocando", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
    }

    // Notificação igual à do relógio do celular: hora grande + Desligar e Adiar, com ícone de nuvem.
    private Notification buildNotification(String label, String time) {
        Intent open = new Intent(this, MainActivity.class);
        open.putExtra("soninho_alarm", true);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 7, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent snooze = new Intent(this, AlarmService.class);
        snooze.setAction("ADIAR");
        PendingIntent piSnooze = PendingIntent.getService(this, 8, snooze, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        android.widget.RemoteViews rv = new android.widget.RemoteViews(getPackageName(), R.layout.notif_alarm);
        rv.setTextViewText(R.id.notif_time, time);
        rv.setTextViewText(R.id.notif_label, label);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_soninho)
                .setContentTitle("Alarme")
                .setContentText(time)
                .setCustomContentView(rv)
                .setCustomBigContentView(rv)
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .addAction(new Notification.Action.Builder(null, "Desligar", pi).build())
                .addAction(new Notification.Action.Builder(null, "Adiar", piSnooze).build())
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MAX);
        return b.build();
    }

    private void startVibration() {
        try {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null) return;
            long[] pattern = {0, 700, 500, 700, 1200};
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0),
                        new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
            } else {
                vibrator.vibrate(pattern, 0);
            }
        } catch (Exception ignored) {
        }
    }

    private void startSound(String toneJson) {
        // Volume do alarme do celular no máximo (o som baixo vinha daqui).
        try {
            AudioManager vol = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (vol != null) vol.setStreamVolume(AudioManager.STREAM_ALARM, vol.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
        } catch (Exception ignored) {
        }
        JSONObject tone = null;
        try {
            tone = new JSONObject(toneJson);
        } catch (Exception ignored) {
        }
        JSONArray notes = tone == null ? null : tone.optJSONArray("notes");
        boolean useSystem = tone == null || tone.optBoolean("system", false) || notes == null || notes.length() == 0;
        if (tone != null && tone.optBoolean("custom", false) && customFile(this).exists()) {
            if (!startCustomSound()) startSynth(defaultTone());
            return;
        }
        if (!useSystem) {
            startSynth(tone);
        } else if (!startSystemSound()) {
            startSynth(defaultTone());
        }
    }

    private JSONObject defaultTone() {
        JSONObject t = new JSONObject();
        try {
            t.put("wave", "triangle");
            t.put("step", 280);
            t.put("notes", new JSONArray(new double[]{523.25, 659.25, 783.99, 659.25, 880.0, 783.99, 659.25, 587.33}));
        } catch (Exception ignored) {
        }
        return t;
    }

    // Áudio próprio da pessoa (WAV salvo no aparelho), em loop.
    private boolean startCustomSound() {
        try {
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            mp.setDataSource(customFile(this).getAbsolutePath());
            mp.setLooping(true);
            mp.prepare();
            float g = gain();
            mp.setVolume(g, g);
            mp.start();
            player = mp;
            handler.postDelayed(rampTick, 500);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Toque do celular (o som de alarme padrão do Android).
    private boolean startSystemSound() {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mp.setDataSource(this, uri);
            mp.setLooping(true);
            mp.prepare();
            float g = gain();
            mp.setVolume(g, g);
            mp.start();
            player = mp;
            handler.postDelayed(rampTick, 500);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Melodias do Soninho: o app manda as notas e o celular toca em loop.
    private void startSynth(JSONObject tone) {
        final String wave = tone.optString("wave", "triangle");
        final int stepMs = Math.max(80, tone.optInt("step", 280));
        final JSONArray notes = tone.optJSONArray("notes");
        final int rate = 22050;
        playing = true;
        synth = new Thread(new Runnable() {
            @Override
            public void run() {
                AudioTrack track = null;
                try {
                    final short[] loop = buildLoop(notes, wave, stepMs, rate);
                    int minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                    track = new AudioTrack(AudioManager.STREAM_ALARM, rate, AudioFormat.CHANNEL_OUT_MONO,
                            AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, 8192), AudioTrack.MODE_STREAM);
                    track.play();
                    final int chunk = 2048;
                    while (playing) {
                        for (int pos = 0; pos < loop.length && playing; pos += chunk) {
                            track.setVolume(gain());
                            track.write(loop, pos, Math.min(chunk, loop.length - pos));
                        }
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (track != null) {
                        try {
                            track.stop();
                        } catch (Throwable ignored) {
                        }
                        track.release();
                    }
                }
            }
        });
        synth.start();
    }

    private short[] buildLoop(JSONArray notes, String wave, int stepMs, int rate) {
        int n = notes == null ? 0 : notes.length();
        int stepSamples = rate * stepMs / 1000;
        int noteLen = (int) (stepSamples * 1.6);
        int total = stepSamples * n + noteLen + rate * 6 / 10;
        float[] acc = new float[total];
        double durSec = noteLen / (double) rate;
        for (int k = 0; k < n; k++) {
            double f = notes.optDouble(k, 0);
            if (f <= 0) continue;
            int base = k * stepSamples;
            double phase = 0;
            double inc = f / rate;
            for (int j = 0; j < noteLen && base + j < total; j++) {
                double t = j / (double) rate;
                double env = Math.min(1.0, t / 0.02) * Math.exp(-4.0 * t / durSec);
                acc[base + j] += (float) (osc(wave, phase) * env * 0.8);
                phase += inc;
            }
        }
        short[] out = new short[total];
        for (int i = 0; i < total; i++) {
            float v = Math.max(-1f, Math.min(1f, acc[i]));
            out[i] = (short) (v * 32500);
        }
        return out;
    }

    private double osc(String wave, double phase) {
        double x = phase - Math.floor(phase);
        if ("sine".equals(wave)) return Math.sin(2 * Math.PI * x);
        if ("square".equals(wave)) return x < 0.5 ? 0.7 : -0.7;
        if ("sawtooth".equals(wave)) return (2 * x - 1) * 0.6;
        return 4 * Math.abs(x - 0.5) - 1;
    }

    private void stopSound() {
        playing = false;
        handler.removeCallbacks(rampTick);
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
        synth = null;
    }
}
