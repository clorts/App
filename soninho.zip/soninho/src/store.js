import { TABLE } from "./config.js";
import { supabase } from "./supabase.js";

const KEY = "soninho:alarms";
const listeners = new Set();

const sortByTime = (list) => [...list].sort((a, b) => a.time.localeCompare(b.time));

function readLocal() {
  try {
    return sortByTime(JSON.parse(localStorage.getItem(KEY) || "[]"));
  } catch {
    return [];
  }
}

let alarms = readLocal();
let userId = null;

function emit() {
  try {
    localStorage.setItem(KEY, JSON.stringify(alarms));
  } catch {
    /* armazenamento cheio ou bloqueado */
  }
  listeners.forEach((fn) => fn(alarms));
}

const remote = () => Boolean(supabase && userId);

export const getAlarms = () => alarms;

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

// Chamado quando alguém entra (id) ou sai (null) da conta.
export async function setUser(id) {
  userId = id;
  if (!supabase || !id) return;
  const { data, error } = await supabase.from(TABLE).select("id,label,time,days,enabled");
  if (error || !data) return console.warn("Erro ao buscar alarmes:", error);
  if (data.length > 0) {
    alarms = sortByTime(data);
    emit();
  } else if (alarms.length > 0) {
    // Nuvem vazia: envia os alarmes que já estavam no aparelho.
    const { error: err } = await supabase.from(TABLE).insert(alarms.map((a) => ({ ...a, user_id: id })));
    if (err) console.warn("Erro ao enviar alarmes:", err);
  }
}

// Ao sair da conta, limpa o aparelho para não misturar com outra pessoa.
export function clearLocal() {
  alarms = [];
  emit();
}

export async function addAlarm(draft) {
  const alarm = { id: crypto.randomUUID(), enabled: true, ...draft };
  alarms = sortByTime([...alarms, alarm]);
  emit();
  if (remote()) {
    const { error } = await supabase.from(TABLE).insert({ ...alarm, user_id: userId });
    if (error) console.warn("Erro ao salvar:", error);
  }
}

export async function patchAlarm(id, changes) {
  alarms = sortByTime(alarms.map((a) => (a.id === id ? { ...a, ...changes } : a)));
  emit();
  if (remote()) {
    const { error } = await supabase.from(TABLE).update(changes).eq("id", id);
    if (error) console.warn("Erro ao atualizar:", error);
  }
}

export async function removeAlarm(id) {
  alarms = alarms.filter((a) => a.id !== id);
  emit();
  if (remote()) {
    const { error } = await supabase.from(TABLE).delete().eq("id", id);
    if (error) console.warn("Erro ao apagar:", error);
  }
}
