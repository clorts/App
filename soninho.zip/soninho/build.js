// Gera a pasta "dist" (a página que o navegador abre) a partir do JavaScript em src/.
// Não precisa de npm install: só Node.js.
import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const dist = join(root, "dist");

rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });
cpSync(join(root, "src"), join(dist, "src"), { recursive: true });

// No APK, o JavaScript do Capacitor vem do node_modules (no Netlify não existe, e tudo bem).
const core = join(root, "node_modules", "@capacitor", "core", "dist", "index.js");
if (existsSync(core)) {
  mkdirSync(join(dist, "src", "vendor"), { recursive: true });
  cpSync(core, join(dist, "src", "vendor", "capacitor-core.js"));
}

const page = [
  "<!doctype html>",
  '<html lang="pt-BR">',
  "<head>",
  '<meta charset="UTF-8" />',
  '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />',
  '<meta name="theme-color" content="#ffc7de" />',
  "<title>Soninho ☁️ Despertador Fofo</title>",
  "</head>",
  "<body>",
  '<script type="module" src="/src/main.js"></script>',
  "</body>",
  "</html>",
  "",
].join("\n");

writeFileSync(join(dist, "index.html"), page);
// No Netlify: se o soninho.apk estiver na pasta do projeto, ele vai junto para o site (link direto, sem GitHub).
if (process.env.NETLIFY && existsSync(join(root, "soninho.apk"))) cpSync(join(root, "soninho.apk"), join(dist, "soninho.apk"));
// O app instalado (APK) lê este arquivo para saber se existe versão nova.
const { version } = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
writeFileSync(join(dist, "version.json"), JSON.stringify({ version }));
console.log("Soninho pronto na pasta dist/ ☁️");
