// Ajustes do app (ficam salvos no aparelho).
const KEY = "soninho:settings";

const DEFAULTS = {
  theme: "claro", // "claro" | "escuro"
  mascot: "nuvi", // "nuvi" | "gatinho" | "ursinho"
  dismiss: "stars", // "stars" | "math" | "shake" | "phrase"
  soft: false, // volume suave (vai subindo aos poucos)
  tone: "melodia", // toque padrão
  bedtimeOn: false,
  bedtime: "22:30",
};

function read() {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "{}");
  } catch {
    return {};
  }
}

let data = { ...DEFAULTS, ...read() };
const listeners = new Set();

export const get = () => data;

export function set(patch) {
  data = { ...data, ...patch };
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* ignora */
  }
  listeners.forEach((fn) => fn(data));
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
