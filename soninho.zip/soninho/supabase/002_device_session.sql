-- Rode no Supabase: SQL Editor > New query > cole tudo > Run.
-- Guarda, por aparelho, a última conta usada (para entrar sozinho depois de reinstalar o app).
create table if not exists public.soninho_device_session (
  device_key text primary key,
  refresh_token text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  updated_at timestamptz not null default now()
);
alter table public.soninho_device_session enable row level security; -- sem policies: só as funções abaixo acessam

create or replace function public.soninho_save_device(p_key text, p_token text, p_user uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if length(p_key) < 32 or auth.uid() is distinct from p_user then raise exception 'nao autorizado'; end if;
  insert into public.soninho_device_session(device_key, refresh_token, user_id, updated_at)
  values (p_key, p_token, p_user, now())
  on conflict (device_key) do update set refresh_token = excluded.refresh_token, user_id = excluded.user_id, updated_at = now();
end $$;

create or replace function public.soninho_get_device(p_key text) returns text
language sql security definer set search_path = public as $$
  select refresh_token from public.soninho_device_session where device_key = p_key and length(p_key) >= 32;
$$;

create or replace function public.soninho_clear_device(p_key text) returns void
language sql security definer set search_path = public as $$
  delete from public.soninho_device_session where device_key = p_key and user_id = auth.uid();
$$;

-- Apagar a própria conta e todos os dados (direito de exclusão - LGPD).
create or replace function public.soninho_delete_me() returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if auth.uid() is null then raise exception 'nao autorizado'; end if;
  delete from auth.users where id = auth.uid();
end $$;

revoke all on function public.soninho_save_device(text, text, uuid) from public;
revoke all on function public.soninho_get_device(text) from public;
revoke all on function public.soninho_clear_device(text) from public;
revoke all on function public.soninho_delete_me() from public;
grant execute on function public.soninho_save_device(text, text, uuid) to authenticated;
grant execute on function public.soninho_get_device(text) to anon, authenticated;
grant execute on function public.soninho_clear_device(text) to authenticated;
grant execute on function public.soninho_delete_me() to authenticated;
