package __PACKAGE__;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import android.provider.Settings;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import org.json.JSONObject;

// Ponte entre o JavaScript do Soninho e o despertador nativo do Android.
@CapacitorPlugin(name = "SoninhoAlarm")
public class SoninhoAlarmPlugin extends Plugin {

    @PluginMethod
    public void schedule(PluginCall call) {
        JSArray alarms = call.getArray("alarms");
        AlarmScheduler.saveAndSchedule(getContext(), alarms == null ? "[]" : alarms.toString());
        call.resolve();
    }

    // Guarda o áudio próprio (WAV gerado pelo app). Confere tamanho e assinatura antes de gravar.
    @PluginMethod
    public void saveCustomSound(PluginCall call) {
        String b64 = call.getString("data");
        if (b64 == null || b64.length() > 3000000) {
            call.reject("arquivo invalido");
            return;
        }
        try {
            byte[] d = Base64.decode(b64, Base64.DEFAULT);
            boolean riff = d.length > 44 && d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F' && d[8] == 'W' && d[9] == 'A' && d[10] == 'V' && d[11] == 'E';
            if (!riff || d.length > 2000000) {
                call.reject("arquivo invalido");
                return;
            }
            FileOutputStream out = new FileOutputStream(AlarmService.customFile(getContext()));
            try {
                out.write(d);
            } finally {
                out.close();
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("erro ao salvar");
        }
    }

    @PluginMethod
    public void deleteCustomSound(PluginCall call) {
        File f = AlarmService.customFile(getContext());
        if (f.exists()) f.delete();
        call.resolve();
    }

    @PluginMethod
    public void getDeviceKey(PluginCall call) {
        try {
            String id = Settings.Secure.getString(getContext().getContentResolver(), Settings.Secure.ANDROID_ID);
            if (id == null || id.isEmpty()) {
                call.reject("sem id");
                return;
            }
            byte[] h = MessageDigest.getInstance("SHA-256").digest((id + "|soninho|" + getContext().getPackageName()).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format("%02x", b));
            JSObject res = new JSObject();
            res.put("key", sb.toString());
            call.resolve(res);
        } catch (Exception e) {
            call.reject("erro");
        }
    }

    @PluginMethod
    public void getRinging(PluginCall call) {
        JSObject res = new JSObject();
        JSONObject cur = AlarmService.ringing;
        if (cur != null) {
            res.put("ringing", true);
            res.put("alarmId", cur.optString("alarmId", ""));
            res.put("label", cur.optString("label", ""));
            res.put("time", cur.optString("time", ""));
        } else {
            res.put("ringing", false);
        }
        call.resolve(res);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        AlarmService.stopNow(getContext());
        call.resolve();
    }

    @PluginMethod
    public void snooze(PluginCall call) {
        int minutes = call.getInt("minutes", 5);
        JSObject tone = call.getObject("tone");
        boolean soft = call.getBoolean("soft", false);
        AlarmService.stopNow(getContext());
        AlarmScheduler.scheduleSnooze(getContext(), minutes, tone == null ? "{}" : tone.toString(), soft);
        call.resolve();
    }
}
