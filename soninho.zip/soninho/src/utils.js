export const pad = (n) => String(n).padStart(2, "0");
export const toHHMM = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;

export function greetingFor(hour) {
  if (hour < 6) return "Ainda é madrugada 🌙";
  if (hour < 12) return "Bom dia! ☀️";
  if (hour < 18) return "Boa tarde! 🌼";
  return "Boa noite! ✨";
}

// Próximo alarme ligado nos próximos 7 dias.
export function nextAlarm(alarms, now) {
  let best = null;
  for (const a of alarms.filter((x) => x.enabled)) {
    if (a.date) {
      const t = new Date(`${a.date}T${a.time}:00`);
      const diff = t.getTime() - now.getTime();
      if (diff > 0 && (!best || diff < best.diff)) best = { alarm: a, diff };
      continue;
    }
    const [hh, mm] = a.time.split(":").map(Number);
    for (let add = 0; add < 8; add++) {
      const t = new Date(now);
      t.setDate(now.getDate() + add);
      t.setHours(hh, mm, 0, 0);
      if (t.getTime() <= now.getTime()) continue;
      if (a.days.length > 0 && !a.days.includes(t.getDay())) continue;
      const diff = t.getTime() - now.getTime();
      if (!best || diff < best.diff) best = { alarm: a, diff };
      break;
    }
  }
  return best ? best.alarm : null;
}
